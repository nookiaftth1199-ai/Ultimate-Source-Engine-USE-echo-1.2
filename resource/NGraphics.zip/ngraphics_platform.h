
// ngraphics_platform.h – platform detection and surface structures

#ifndef NGRAPHICS_PLATFORM_H
#define NGRAPHICS_PLATFORM_H

#ifdef __cplusplus
extern "C" {
#endif

#if defined(_WIN32) || defined(_WIN64)
    #define NGFX_PLATFORM_WINDOWS 1
#elif defined(__ANDROID__)
    #define NGFX_PLATFORM_ANDROID 1
#elif defined(__linux__)
    #define NGFX_PLATFORM_LINUX 1
#elif defined(__APPLE__)
    #include <TargetConditionals.h>
    #if TARGET_OS_IPHONE || TARGET_IPHONE_SIMULATOR
        #define NGFX_PLATFORM_IOS 1
    #elif TARGET_OS_MAC
        #define NGFX_PLATFORM_MACOS 1
    #endif
#else
    #error "Unsupported platform"
#endif

// Windows
#ifdef NGFX_PLATFORM_WINDOWS
    #ifndef WIN32_LEAN_AND_MEAN
        #define WIN32_LEAN_AND_MEAN
    #endif
    #include <windows.h>
    typedef HWND      NGFXNativeWindowHandle;
    typedef HINSTANCE NGFXNativeInstanceHandle;
#endif

// Android
#ifdef NGFX_PLATFORM_ANDROID
    #include <android/native_window.h>
    #include <jni.h>
    typedef ANativeWindow* NGFXNativeWindowHandle;
    typedef JavaVM* NGFXJavaVM;
#endif

// Linux
#ifdef NGFX_PLATFORM_LINUX
    #include <X11/Xlib.h>
    #include <X11/Xutil.h>
    typedef Display* NGFXXDisplay;
    typedef Window   NGFXXWindow;
#endif

// macOS
#ifdef NGFX_PLATFORM_MACOS
    #include <CoreFoundation/CoreFoundation.h>
    typedef const void* NGFXNSView;
    typedef const void* NGFXCALayer;
#endif

// iOS
#ifdef NGFX_PLATFORM_IOS
    #include <CoreFoundation/CoreFoundation.h>
    typedef const void* NGFXUIView;
    typedef const void* NGFXCALayer;
#endif

// Surface creation structures

#ifdef NGFX_PLATFORM_WINDOWS
typedef struct NGFX_Win32SurfaceCreateInfo {
    void* hinstance;
    void* hwnd;
} NGFX_Win32SurfaceCreateInfo;
#endif

#ifdef NGFX_PLATFORM_ANDROID
typedef struct NGFX_AndroidSurfaceCreateInfo {
    ANativeWindow* window;
} NGFX_AndroidSurfaceCreateInfo;
#endif

#ifdef NGFX_PLATFORM_LINUX
typedef struct NGFX_XlibSurfaceCreateInfo {
    Display* dpy;
    Window   window;
} NGFX_XlibSurfaceCreateInfo;
#endif

#ifdef NGFX_PLATFORM_MACOS
typedef struct NGFX_MacOSSurfaceCreateInfo {
    const void* pView;
    const void* pLayer;
} NGFX_MacOSSurfaceCreateInfo;
#endif

#ifdef NGFX_PLATFORM_IOS
typedef struct NGFX_IOSSurfaceCreateInfo {
    const void* pView;
    const void* pLayer;
} NGFX_IOSSurfaceCreateInfo;
#endif

#ifdef __cplusplus
}
#endif

#endif // NGRAPHICS_PLATFORM_H