
// ngfx_buffer.c – buffer functions

#include "ngraphics.h"
#include "ngfx_dispatch.h"

NGFX_API NGFX_Result ngfxCreateBuffer(NGFX_Device device,
                                      const NGFX_BufferCreateInfo* pCreateInfo,
                                      NGFX_Buffer* pBuffer) {
    if (!device || !pCreateInfo || !pBuffer)
        return NGFX_ERROR_INITIALIZATION_FAILED;
    if (!g_dispatch.CreateBuffer)
        return NGFX_ERROR_INITIALIZATION_FAILED;
    return g_dispatch.CreateBuffer(device, pCreateInfo, pBuffer);
}

NGFX_API void ngfxDestroyBuffer(NGFX_Device device, NGFX_Buffer buffer) {
    if (device && buffer && g_dispatch.DestroyBuffer)
        g_dispatch.DestroyBuffer(device, buffer);
}