
// swr_command.c – software backend command buffer management

#include "ngraphics.h"
#include "ngfx_dispatch.h"
#include "swr_common.h"
#include <stdlib.h>
#include <string.h>

static NGFX_Result swrCreateCommandPool(NGFX_Device device,
                                        const NGFX_CommandPoolCreateInfo* pCreateInfo,
                                        NGFX_CommandPool* pPool) {
    (void)device; (void)pCreateInfo;
    SwrCommandPool* pool = (SwrCommandPool*)malloc(sizeof(SwrCommandPool));
    if (!pool) return NGFX_ERROR_OUT_OF_HOST_MEMORY;
    pool->dummy = 0;
    *pPool = (NGFX_CommandPool)pool;
    return NGFX_SUCCESS;
}

static void swrDestroyCommandPool(NGFX_Device device, NGFX_CommandPool pool) {
    (void)device;
    if (pool) free(pool);
}

static NGFX_Result swrAllocateCommandBuffers(NGFX_Device device,
                                              const NGFX_CommandBufferAllocateInfo* pAllocateInfo,
                                              NGFX_CommandBuffer* pCommandBuffers) {
    (void)device;
    if (!pAllocateInfo || !pCommandBuffers || pAllocateInfo->commandBufferCount == 0)
        return NGFX_ERROR_INITIALIZATION_FAILED;
    for (uint32_t i = 0; i < pAllocateInfo->commandBufferCount; ++i) {
        SwrCommandBuffer* cmdBuf = (SwrCommandBuffer*)calloc(1, sizeof(SwrCommandBuffer));
        if (!cmdBuf) {
            for (uint32_t j = 0; j < i; ++j) {
                SwrCommandBuffer* old = (SwrCommandBuffer*)pCommandBuffers[j];
                if (old->commands) free(old->commands);
                free(old);
            }
            return NGFX_ERROR_OUT_OF_HOST_MEMORY;
        }
        cmdBuf->capacity = 16;
        cmdBuf->count = 0;
        cmdBuf->commands = (SwrCommand*)malloc(cmdBuf->capacity * sizeof(SwrCommand));
        if (!cmdBuf->commands) {
            free(cmdBuf);
            return NGFX_ERROR_OUT_OF_HOST_MEMORY;
        }
        pCommandBuffers[i] = (NGFX_CommandBuffer)cmdBuf;
    }
    return NGFX_SUCCESS;
}

static void swrFreeCommandBuffers(NGFX_Device device,
                                   NGFX_CommandPool commandPool,
                                   uint32_t commandBufferCount,
                                   const NGFX_CommandBuffer* pCommandBuffers) {
    (void)device; (void)commandPool;
    for (uint32_t i = 0; i < commandBufferCount; ++i) {
        SwrCommandBuffer* cmdBuf = (SwrCommandBuffer*)pCommandBuffers[i];
        if (cmdBuf) {
            if (cmdBuf->commands) free(cmdBuf->commands);
            free(cmdBuf);
        }
    }
}

static NGFX_Result swrBeginCommandBuffer(NGFX_CommandBuffer commandBuffer,
                                          const NGFX_CommandBufferBeginInfo* pBeginInfo) {
    (void)pBeginInfo;
    SwrCommandBuffer* cmdBuf = (SwrCommandBuffer*)commandBuffer;
    if (!cmdBuf) return NGFX_ERROR_INITIALIZATION_FAILED;
    cmdBuf->count = 0;
    cmdBuf->currentPipeline = NGFX_NULL_HANDLE;
    return NGFX_SUCCESS;
}

static NGFX_Result swrEndCommandBuffer(NGFX_CommandBuffer commandBuffer) {
    (void)commandBuffer;
    return NGFX_SUCCESS;
}

static NGFX_Result swrResetCommandBuffer(NGFX_CommandBuffer commandBuffer,
                                          NGFX_Flags flags) {
    (void)flags;
    SwrCommandBuffer* cmdBuf = (SwrCommandBuffer*)commandBuffer;
    if (!cmdBuf) return NGFX_ERROR_INITIALIZATION_FAILED;
    cmdBuf->count = 0;
    cmdBuf->currentPipeline = NGFX_NULL_HANDLE;
    return NGFX_SUCCESS;
}

// Recording commands
static void swrCmdBindPipeline(NGFX_CommandBuffer commandBuffer,
                                NGFX_PipelineBindPoint pipelineBindPoint,
                                NGFX_Pipeline pipeline) {
    if (pipelineBindPoint != NGFX_PIPELINE_BIND_POINT_GRAPHICS) return;
    SwrCommandBuffer* cmdBuf = (SwrCommandBuffer*)commandBuffer;
    if (!cmdBuf) return;
    if (!swr_ensure_command_space(cmdBuf)) return;
    SwrCommand* cmd = &cmdBuf->commands[cmdBuf->count++];
    cmd->type = SWR_CMD_BIND_PIPELINE;
    cmd->data.bindPipeline.pipeline = pipeline;
    cmdBuf->currentPipeline = pipeline;
}

static void swrCmdBindVertexBuffers(NGFX_CommandBuffer commandBuffer,
                                      uint32_t firstBinding,
                                      uint32_t bindingCount,
                                      const NGFX_Buffer* pBuffers,
                                      const NGFX_DeviceSize* pOffsets) {
    SwrCommandBuffer* cmdBuf = (SwrCommandBuffer*)commandBuffer;
    if (!cmdBuf || bindingCount == 0 || !pBuffers || !pOffsets) return;
    if (!swr_ensure_command_space(cmdBuf)) return;
    SwrCommand* cmd = &cmdBuf->commands[cmdBuf->count++];
    cmd->type = SWR_CMD_BIND_VERTEX_BUFFERS;
    cmd->data.bindVertexBuffers.firstBinding = firstBinding;
    cmd->data.bindVertexBuffers.bindingCount = bindingCount;
    size_t bufSize = bindingCount * sizeof(NGFX_Buffer);
    size_t offSize = bindingCount * sizeof(NGFX_DeviceSize);
    cmd->data.bindVertexBuffers.buffers = (NGFX_Buffer*)swr_copy_data(pBuffers, bufSize);
    cmd->data.bindVertexBuffers.offsets = (NGFX_DeviceSize*)swr_copy_data(pOffsets, offSize);
}

static void swrCmdBindIndexBuffer(NGFX_CommandBuffer commandBuffer,
                                    NGFX_Buffer buffer,
                                    NGFX_DeviceSize offset,
                                    NGFX_IndexType indexType) {
    SwrCommandBuffer* cmdBuf = (SwrCommandBuffer*)commandBuffer;
    if (!cmdBuf) return;
    if (!swr_ensure_command_space(cmdBuf)) return;
    SwrCommand* cmd = &cmdBuf->commands[cmdBuf->count++];
    cmd->type = SWR_CMD_BIND_INDEX_BUFFER;
    cmd->data.bindIndexBuffer.buffer = buffer;
    cmd->data.bindIndexBuffer.offset = offset;
    cmd->data.bindIndexBuffer.indexType = indexType;
}

static void swrCmdDraw(NGFX_CommandBuffer commandBuffer,
                        uint32_t vertexCount,
                        uint32_t instanceCount,
                        uint32_t firstVertex,
                        uint32_t firstInstance) {
    SwrCommandBuffer* cmdBuf = (SwrCommandBuffer*)commandBuffer;
    if (!cmdBuf) return;
    if (!swr_ensure_command_space(cmdBuf)) return;
    SwrCommand* cmd = &cmdBuf->commands[cmdBuf->count++];
    cmd->type = SWR_CMD_DRAW;
    cmd->data.draw.vertexCount = vertexCount;
    cmd->data.draw.instanceCount = instanceCount;
    cmd->data.draw.firstVertex = firstVertex;
    cmd->data.draw.firstInstance = firstInstance;
}

static void swrCmdDrawIndexed(NGFX_CommandBuffer commandBuffer,
                               uint32_t indexCount,
                               uint32_t instanceCount,
                               uint32_t firstIndex,
                               int32_t vertexOffset,
                               uint32_t firstInstance) {
    SwrCommandBuffer* cmdBuf = (SwrCommandBuffer*)commandBuffer;
    if (!cmdBuf) return;
    if (!swr_ensure_command_space(cmdBuf)) return;
    SwrCommand* cmd = &cmdBuf->commands[cmdBuf->count++];
    cmd->type = SWR_CMD_DRAW_INDEXED;
    cmd->data.drawIndexed.indexCount = indexCount;
    cmd->data.drawIndexed.instanceCount = instanceCount;
    cmd->data.drawIndexed.firstIndex = firstIndex;
    cmd->data.drawIndexed.vertexOffset = vertexOffset;
    cmd->data.drawIndexed.firstInstance = firstInstance;
}

static void swrCmdSetViewport(NGFX_CommandBuffer commandBuffer,
                                uint32_t firstViewport,
                                uint32_t viewportCount,
                                const NGFX_Viewport* pViewports) {
    SwrCommandBuffer* cmdBuf = (SwrCommandBuffer*)commandBuffer;
    if (!cmdBuf || viewportCount == 0 || !pViewports) return;
    if (!swr_ensure_command_space(cmdBuf)) return;
    SwrCommand* cmd = &cmdBuf->commands[cmdBuf->count++];
    cmd->type = SWR_CMD_SET_VIEWPORT;
    cmd->data.setViewport.firstViewport = firstViewport;
    cmd->data.setViewport.viewportCount = viewportCount;
    size_t size = viewportCount * sizeof(NGFX_Viewport);
    cmd->data.setViewport.viewports = (NGFX_Viewport*)swr_copy_data(pViewports, size);
}

static void swrCmdSetScissor(NGFX_CommandBuffer commandBuffer,
                               uint32_t firstScissor,
                               uint32_t scissorCount,
                               const NGFX_Rect2D* pScissors) {
    SwrCommandBuffer* cmdBuf = (SwrCommandBuffer*)commandBuffer;
    if (!cmdBuf || scissorCount == 0 || !pScissors) return;
    if (!swr_ensure_command_space(cmdBuf)) return;
    SwrCommand* cmd = &cmdBuf->commands[cmdBuf->count++];
    cmd->type = SWR_CMD_SET_SCISSOR;
    cmd->data.setScissor.firstScissor = firstScissor;
    cmd->data.setScissor.scissorCount = scissorCount;
    size_t size = scissorCount * sizeof(NGFX_Rect2D);
    cmd->data.setScissor.scissors = (NGFX_Rect2D*)swr_copy_data(pScissors, size);
}

static void swrCmdBeginRenderPass(NGFX_CommandBuffer commandBuffer,
                                    const void* pRenderPassBegin,
                                    uint32_t contents) {
    (void)contents;
    SwrCommandBuffer* cmdBuf = (SwrCommandBuffer*)commandBuffer;
    if (!cmdBuf || !pRenderPassBegin) return;
    if (!swr_ensure_command_space(cmdBuf)) return;
    const NGFX_RenderPassBeginInfo* beginInfo = (const NGFX_RenderPassBeginInfo*)pRenderPassBegin;
    SwrCommand* cmd = &cmdBuf->commands[cmdBuf->count++];
    cmd->type = SWR_CMD_BEGIN_RENDERPASS;
    cmd->data.beginRenderPass.framebuffer = beginInfo->framebuffer;
    cmd->data.beginRenderPass.renderPass = beginInfo->renderPass;
    cmd->data.beginRenderPass.renderArea = beginInfo->renderArea;
    cmd->data.beginRenderPass.clearValueCount = beginInfo->clearValueCount;
    if (beginInfo->clearValueCount > 0 && beginInfo->pClearValues) {
        size_t size = beginInfo->clearValueCount * sizeof(NGFX_ClearValue);
        cmd->data.beginRenderPass.clearValues = swr_copy_data(beginInfo->pClearValues, size);
    } else {
        cmd->data.beginRenderPass.clearValues = NULL;
    }
}

static void swrCmdEndRenderPass(NGFX_CommandBuffer commandBuffer) {
    SwrCommandBuffer* cmdBuf = (SwrCommandBuffer*)commandBuffer;
    if (!cmdBuf) return;
    if (!swr_ensure_command_space(cmdBuf)) return;
    SwrCommand* cmd = &cmdBuf->commands[cmdBuf->count++];
    cmd->type = SWR_CMD_END_RENDERPASS;
}

void swr_load_command_dispatch(NGFX_DispatchTable* dispatch) {
    if (!dispatch) return;
    dispatch->CreateCommandPool = swrCreateCommandPool;
    dispatch->DestroyCommandPool = swrDestroyCommandPool;
    dispatch->AllocateCommandBuffers = swrAllocateCommandBuffers;
    dispatch->FreeCommandBuffers = swrFreeCommandBuffers;
    dispatch->BeginCommandBuffer = swrBeginCommandBuffer;
    dispatch->EndCommandBuffer = swrEndCommandBuffer;
    dispatch->ResetCommandBuffer = swrResetCommandBuffer;
    dispatch->CmdBindPipeline = swrCmdBindPipeline;
    dispatch->CmdBindVertexBuffers = swrCmdBindVertexBuffers;
    dispatch->CmdBindIndexBuffer = swrCmdBindIndexBuffer;
    dispatch->CmdDraw = swrCmdDraw;
    dispatch->CmdDrawIndexed = swrCmdDrawIndexed;
    dispatch->CmdSetViewport = swrCmdSetViewport;
    dispatch->CmdSetScissor = swrCmdSetScissor;
    dispatch->CmdBeginRenderPass = swrCmdBeginRenderPass;
    dispatch->CmdEndRenderPass = swrCmdEndRenderPass;
}