
// swr_device.c – software backend device and physical device

#include "ngraphics.h"
#include "ngfx_dispatch.h"
#include "swr_common.h"
#include <stdlib.h>
#include <string.h>

typedef struct SwrPhysicalDevice {
    int dummy;
} SwrPhysicalDevice;

typedef struct SwrDevice {
    SwrPhysicalDevice* physicalDevice;
    struct SwrQueue* queue;
} SwrDevice;

typedef struct SwrQueue {
    SwrDevice* device;
    uint32_t queueFamilyIndex;
    uint32_t queueIndex;
} SwrQueue;

// Physical device
static NGFX_Result swrEnumeratePhysicalDevices(NGFX_Instance instance,
                                                uint32_t* pCount,
                                                NGFX_PhysicalDevice* pDevices) {
    (void)instance;
    if (!pCount) return NGFX_ERROR_INITIALIZATION_FAILED;
    if (pDevices == NULL) {
        *pCount = 1;
        return NGFX_SUCCESS;
    }
    if (*pCount < 1) {
        *pCount = 1;
        return NGFX_ERROR_INITIALIZATION_FAILED;
    }
    SwrPhysicalDevice* phys = (SwrPhysicalDevice*)malloc(sizeof(SwrPhysicalDevice));
    if (!phys) return NGFX_ERROR_OUT_OF_HOST_MEMORY;
    phys->dummy = 0;
    *pDevices = (NGFX_PhysicalDevice)phys;
    return NGFX_SUCCESS;
}

static void swrGetPhysicalDeviceProperties(NGFX_PhysicalDevice physicalDevice,
                                            NGFX_PhysicalDeviceProperties* pProperties) {
    if (!physicalDevice || !pProperties) return;
    strncpy(pProperties->deviceName, "NGraphics Software Renderer", sizeof(pProperties->deviceName)-1);
    pProperties->deviceName[sizeof(pProperties->deviceName)-1] = '\0';
    pProperties->apiVersion = NGFX_API_VERSION;
    pProperties->driverVersion = 1;
    pProperties->vendorID = 0;
    pProperties->deviceID = 0;
    pProperties->deviceType = 4;
}

// Device
static NGFX_Result swrCreateDevice(NGFX_PhysicalDevice physicalDevice,
                                    const NGFX_DeviceCreateInfo* pCreateInfo,
                                    NGFX_Device* pDevice) {
    if (!physicalDevice || !pCreateInfo || !pDevice)
        return NGFX_ERROR_INITIALIZATION_FAILED;
    if (pCreateInfo->queueCreateInfoCount == 0 || !pCreateInfo->pQueueCreateInfos)
        return NGFX_ERROR_INITIALIZATION_FAILED;
    SwrDevice* dev = (SwrDevice*)malloc(sizeof(SwrDevice));
    if (!dev) return NGFX_ERROR_OUT_OF_HOST_MEMORY;
    dev->physicalDevice = (SwrPhysicalDevice*)physicalDevice;
    dev->queue = NULL;
    const NGFX_DeviceQueueCreateInfo* qci = &pCreateInfo->pQueueCreateInfos[0];
    if (qci->queueCount > 0) {
        SwrQueue* q = (SwrQueue*)malloc(sizeof(SwrQueue));
        if (!q) { free(dev); return NGFX_ERROR_OUT_OF_HOST_MEMORY; }
        q->device = dev;
        q->queueFamilyIndex = qci->queueFamilyIndex;
        q->queueIndex = 0;
        dev->queue = q;
    }
    *pDevice = (NGFX_Device)dev;
    return NGFX_SUCCESS;
}

static void swrDestroyDevice(NGFX_Device device) {
    if (!device) return;
    SwrDevice* dev = (SwrDevice*)device;
    if (dev->queue) free(dev->queue);
    free(dev);
}

static void swrGetDeviceQueue(NGFX_Device device,
                               uint32_t queueFamilyIndex,
                               uint32_t queueIndex,
                               NGFX_Queue* pQueue) {
    if (!device || !pQueue) return;
    SwrDevice* dev = (SwrDevice*)device;
    if (queueFamilyIndex == 0 && queueIndex == 0 && dev->queue) {
        *pQueue = (NGFX_Queue)dev->queue;
    } else {
        *pQueue = NGFX_NULL_HANDLE;
    }
}

static NGFX_Result swrDeviceWaitIdle(NGFX_Device device) {
    (void)device;
    return NGFX_SUCCESS;
}

// Dispatch loader
extern void swr_load_command_dispatch(NGFX_DispatchTable* dispatch);
extern void swr_load_queue_dispatch(NGFX_DispatchTable* dispatch);
extern void swr_load_pipeline_dispatch(NGFX_DispatchTable* dispatch);
// extern void swr_load_sync_dispatch(NGFX_DispatchTable* dispatch);
// extern void swr_load_renderpass_dispatch(NGFX_DispatchTable* dispatch);
// extern void swr_load_buffer_image_dispatch(NGFX_DispatchTable* dispatch);

void ngfx_swr_load_dispatch(NGFX_DispatchTable* dispatch) {
    if (!dispatch) return;
    dispatch->EnumeratePhysicalDevices = swrEnumeratePhysicalDevices;
    dispatch->GetPhysicalDeviceProperties = swrGetPhysicalDeviceProperties;
    dispatch->CreateDevice = swrCreateDevice;
    dispatch->DestroyDevice = swrDestroyDevice;
    dispatch->GetDeviceQueue = swrGetDeviceQueue;
    dispatch->DeviceWaitIdle = swrDeviceWaitIdle;

    swr_load_command_dispatch(dispatch);
    swr_load_queue_dispatch(dispatch);
    swr_load_pipeline_dispatch(dispatch);
    // swr_load_sync_dispatch(dispatch);
    // swr_load_renderpass_dispatch(dispatch);
    // swr_load_buffer_image_dispatch(dispatch);
}