
// swr_common.h – shared types and utilities for software backend

#ifndef SWR_COMMON_H
#define SWR_COMMON_H

#include "ngraphics.h"
#include <stddef.h>

#ifdef __cplusplus
extern "C" {
#endif

typedef struct SwrShaderModule {
    uint32_t codeSize;
    uint32_t* pCode;
} SwrShaderModule;

typedef struct SwrPipelineLayout {
    int dummy;
} SwrPipelineLayout;

typedef struct SwrPipeline {
    uint32_t stageCount;
    NGFX_PipelineShaderStageCreateInfo* pStages;
    NGFX_PipelineVertexInputStateCreateInfo vertexInputState;
    NGFX_PipelineInputAssemblyStateCreateInfo inputAssemblyState;
    NGFX_PipelineViewportStateCreateInfo viewportState;
    NGFX_PipelineRasterizationStateCreateInfo rasterizationState;
    NGFX_PipelineMultisampleStateCreateInfo multisampleState;
    NGFX_PipelineDepthStencilStateCreateInfo depthStencilState;
    NGFX_PipelineColorBlendStateCreateInfo colorBlendState;
    NGFX_PipelineColorBlendAttachmentState* pAttachments;
    NGFX_PipelineLayout layout;
    NGFX_RenderPass renderPass;
    uint32_t subpass;
} SwrPipeline;

typedef struct SwrVertex {
    float x, y, z;
    float r, g, b, a;
} SwrVertex;

typedef enum SwrCommandType {
    SWR_CMD_BIND_PIPELINE,
    SWR_CMD_BIND_VERTEX_BUFFERS,
    SWR_CMD_BIND_INDEX_BUFFER,
    SWR_CMD_DRAW,
    SWR_CMD_DRAW_INDEXED,
    SWR_CMD_SET_VIEWPORT,
    SWR_CMD_SET_SCISSOR,
    SWR_CMD_BEGIN_RENDERPASS,
    SWR_CMD_END_RENDERPASS,
} SwrCommandType;

typedef struct SwrCmdBindPipeline {
    NGFX_Pipeline pipeline;
} SwrCmdBindPipeline;

typedef struct SwrCmdBindVertexBuffers {
    uint32_t firstBinding;
    uint32_t bindingCount;
    NGFX_Buffer* buffers;
    NGFX_DeviceSize* offsets;
} SwrCmdBindVertexBuffers;

typedef struct SwrCmdBindIndexBuffer {
    NGFX_Buffer buffer;
    NGFX_DeviceSize offset;
    NGFX_IndexType indexType;
} SwrCmdBindIndexBuffer;

typedef struct SwrCmdDraw {
    uint32_t vertexCount;
    uint32_t instanceCount;
    uint32_t firstVertex;
    uint32_t firstInstance;
} SwrCmdDraw;

typedef struct SwrCmdDrawIndexed {
    uint32_t indexCount;
    uint32_t instanceCount;
    uint32_t firstIndex;
    int32_t vertexOffset;
    uint32_t firstInstance;
} SwrCmdDrawIndexed;

typedef struct SwrCmdSetViewport {
    uint32_t firstViewport;
    uint32_t viewportCount;
    NGFX_Viewport* viewports;
} SwrCmdSetViewport;

typedef struct SwrCmdSetScissor {
    uint32_t firstScissor;
    uint32_t scissorCount;
    NGFX_Rect2D* scissors;
} SwrCmdSetScissor;

typedef struct SwrCmdBeginRenderPass {
    NGFX_Framebuffer framebuffer;
    NGFX_RenderPass renderPass;
    NGFX_Rect2D renderArea;
    uint32_t clearValueCount;
    void* clearValues;
} SwrCmdBeginRenderPass;

typedef struct SwrCommand {
    SwrCommandType type;
    union {
        SwrCmdBindPipeline bindPipeline;
        SwrCmdBindVertexBuffers bindVertexBuffers;
        SwrCmdBindIndexBuffer bindIndexBuffer;
        SwrCmdDraw draw;
        SwrCmdDrawIndexed drawIndexed;
        SwrCmdSetViewport setViewport;
        SwrCmdSetScissor setScissor;
        SwrCmdBeginRenderPass beginRenderPass;
    } data;
} SwrCommand;

typedef struct SwrCommandBuffer {
    uint32_t capacity;
    uint32_t count;
    SwrCommand* commands;
    NGFX_Pipeline currentPipeline;
} SwrCommandBuffer;

typedef struct SwrCommandPool {
    int dummy;
} SwrCommandPool;

// Utility functions
int swr_ensure_command_space(SwrCommandBuffer* cmdBuf);
void* swr_copy_data(const void* src, size_t size);

#ifdef __cplusplus
}
#endif

#endif // SWR_COMMON_H
