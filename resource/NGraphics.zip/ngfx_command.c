
// ngfx_command.c – command pool and command buffer functions

#include "ngraphics.h"
#include "ngfx_dispatch.h"

NGFX_API NGFX_Result ngfxCreateCommandPool(NGFX_Device device,
                                           const NGFX_CommandPoolCreateInfo* pCreateInfo,
                                           NGFX_CommandPool* pPool) {
    if (!device || !pCreateInfo || !pPool)
        return NGFX_ERROR_INITIALIZATION_FAILED;
    if (!g_dispatch.CreateCommandPool)
        return NGFX_ERROR_INITIALIZATION_FAILED;
    return g_dispatch.CreateCommandPool(device, pCreateInfo, pPool);
}

NGFX_API void ngfxDestroyCommandPool(NGFX_Device device, NGFX_CommandPool pool) {
    if (device && pool && g_dispatch.DestroyCommandPool)
        g_dispatch.DestroyCommandPool(device, pool);
}

NGFX_API NGFX_Result ngfxAllocateCommandBuffers(NGFX_Device device,
                                                const NGFX_CommandBufferAllocateInfo* pAllocateInfo,
                                                NGFX_CommandBuffer* pCommandBuffers) {
    if (!device || !pAllocateInfo || !pCommandBuffers)
        return NGFX_ERROR_INITIALIZATION_FAILED;
    if (!g_dispatch.AllocateCommandBuffers)
        return NGFX_ERROR_INITIALIZATION_FAILED;
    return g_dispatch.AllocateCommandBuffers(device, pAllocateInfo, pCommandBuffers);
}

NGFX_API void ngfxFreeCommandBuffers(NGFX_Device device,
                                      NGFX_CommandPool commandPool,
                                      uint32_t commandBufferCount,
                                      const NGFX_CommandBuffer* pCommandBuffers) {
    if (device && commandPool && pCommandBuffers && commandBufferCount > 0 && g_dispatch.FreeCommandBuffers)
        g_dispatch.FreeCommandBuffers(device, commandPool, commandBufferCount, pCommandBuffers);
}

NGFX_API NGFX_Result ngfxBeginCommandBuffer(NGFX_CommandBuffer commandBuffer,
                                            const NGFX_CommandBufferBeginInfo* pBeginInfo) {
    if (!commandBuffer)
        return NGFX_ERROR_INITIALIZATION_FAILED;
    if (!g_dispatch.BeginCommandBuffer)
        return NGFX_ERROR_INITIALIZATION_FAILED;
    return g_dispatch.BeginCommandBuffer(commandBuffer, pBeginInfo);
}

NGFX_API NGFX_Result ngfxEndCommandBuffer(NGFX_CommandBuffer commandBuffer) {
    if (!commandBuffer)
        return NGFX_ERROR_INITIALIZATION_FAILED;
    if (!g_dispatch.EndCommandBuffer)
        return NGFX_ERROR_INITIALIZATION_FAILED;
    return g_dispatch.EndCommandBuffer(commandBuffer);
}

NGFX_API NGFX_Result ngfxResetCommandBuffer(NGFX_CommandBuffer commandBuffer,
                                            NGFX_Flags flags) {
    if (!commandBuffer)
        return NGFX_ERROR_INITIALIZATION_FAILED;
    if (!g_dispatch.ResetCommandBuffer)
        return NGFX_ERROR_INITIALIZATION_FAILED;
    return g_dispatch.ResetCommandBuffer(commandBuffer, flags);
}

// Command recording
NGFX_API void ngfxCmdBeginRenderPass(NGFX_CommandBuffer commandBuffer,
                                      const NGFX_RenderPassBeginInfo* pRenderPassBegin,
                                      NGFX_SubpassContents contents) {
    if (commandBuffer && g_dispatch.CmdBeginRenderPass)
        g_dispatch.CmdBeginRenderPass(commandBuffer, (const void*)pRenderPassBegin, (uint32_t)contents);
}

NGFX_API void ngfxCmdEndRenderPass(NGFX_CommandBuffer commandBuffer) {
    if (commandBuffer && g_dispatch.CmdEndRenderPass)
        g_dispatch.CmdEndRenderPass(commandBuffer);
}

NGFX_API void ngfxCmdBindPipeline(NGFX_CommandBuffer commandBuffer,
                                   NGFX_PipelineBindPoint pipelineBindPoint,
                                   NGFX_Pipeline pipeline) {
    if (commandBuffer && g_dispatch.CmdBindPipeline)
        g_dispatch.CmdBindPipeline(commandBuffer, pipelineBindPoint, pipeline);
}

NGFX_API void ngfxCmdBindVertexBuffers(NGFX_CommandBuffer commandBuffer,
                                        uint32_t firstBinding,
                                        uint32_t bindingCount,
                                        const NGFX_Buffer* pBuffers,
                                        const NGFX_DeviceSize* pOffsets) {
    if (commandBuffer && pBuffers && g_dispatch.CmdBindVertexBuffers)
        g_dispatch.CmdBindVertexBuffers(commandBuffer, firstBinding, bindingCount, pBuffers, pOffsets);
}

NGFX_API void ngfxCmdBindIndexBuffer(NGFX_CommandBuffer commandBuffer,
                                      NGFX_Buffer buffer,
                                      NGFX_DeviceSize offset,
                                      NGFX_IndexType indexType) {
    if (commandBuffer && g_dispatch.CmdBindIndexBuffer)
        g_dispatch.CmdBindIndexBuffer(commandBuffer, buffer, offset, indexType);
}

NGFX_API void ngfxCmdDraw(NGFX_CommandBuffer commandBuffer,
                          uint32_t vertexCount,
                          uint32_t instanceCount,
                          uint32_t firstVertex,
                          uint32_t firstInstance) {
    if (commandBuffer && g_dispatch.CmdDraw)
        g_dispatch.CmdDraw(commandBuffer, vertexCount, instanceCount, firstVertex, firstInstance);
}

NGFX_API void ngfxCmdDrawIndexed(NGFX_CommandBuffer commandBuffer,
                                 uint32_t indexCount,
                                 uint32_t instanceCount,
                                 uint32_t firstIndex,
                                 int32_t vertexOffset,
                                 uint32_t firstInstance) {
    if (commandBuffer && g_dispatch.CmdDrawIndexed)
        g_dispatch.CmdDrawIndexed(commandBuffer, indexCount, instanceCount, firstIndex, vertexOffset, firstInstance);
}

NGFX_API void ngfxCmdSetViewport(NGFX_CommandBuffer commandBuffer,
                                  uint32_t firstViewport,
                                  uint32_t viewportCount,
                                  const NGFX_Viewport* pViewports) {
    if (commandBuffer && pViewports && g_dispatch.CmdSetViewport)
        g_dispatch.CmdSetViewport(commandBuffer, firstViewport, viewportCount, pViewports);
}

NGFX_API void ngfxCmdSetScissor(NGFX_CommandBuffer commandBuffer,
                                 uint32_t firstScissor,
                                 uint32_t scissorCount,
                                 const NGFX_Rect2D* pScissors) {
    if (commandBuffer && pScissors && g_dispatch.CmdSetScissor)
        g_dispatch.CmdSetScissor(commandBuffer, firstScissor, scissorCount, pScissors);
}