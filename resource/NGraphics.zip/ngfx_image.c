cat > ngfx_image.c << 'EOF'
// ngfx_image.c – image, image view, sampler functions

#include "ngraphics.h"
#include "ngfx_dispatch.h"

NGFX_API NGFX_Result ngfxCreateImage(NGFX_Device device,
                                     const NGFX_ImageCreateInfo* pCreateInfo,
                                     NGFX_Image* pImage) {
    if (!device || !pCreateInfo || !pImage)
        return NGFX_ERROR_INITIALIZATION_FAILED;
    if (!g_dispatch.CreateImage)
        return NGFX_ERROR_INITIALIZATION_FAILED;
    return g_dispatch.CreateImage(device, pCreateInfo, pImage);
}

NGFX_API void ngfxDestroyImage(NGFX_Device device, NGFX_Image image) {
    if (device && image && g_dispatch.DestroyImage)
        g_dispatch.DestroyImage(device, image);
}

NGFX_API NGFX_Result ngfxCreateImageView(NGFX_Device device,
                                         const NGFX_ImageViewCreateInfo* pCreateInfo,
                                         NGFX_ImageView* pImageView) {
    if (!device || !pCreateInfo || !pImageView)
        return NGFX_ERROR_INITIALIZATION_FAILED;
    if (!g_dispatch.CreateImageView)
        return NGFX_ERROR_INITIALIZATION_FAILED;
    return g_dispatch.CreateImageView(device, pCreateInfo, pImageView);
}

NGFX_API void ngfxDestroyImageView(NGFX_Device device, NGFX_ImageView imageView) {
    if (device && imageView && g_dispatch.DestroyImageView)
        g_dispatch.DestroyImageView(device, imageView);
}

NGFX_API NGFX_Result ngfxCreateSampler(NGFX_Device device,
                                       const NGFX_SamplerCreateInfo* pCreateInfo,
                                       NGFX_Sampler* pSampler) {
    if (!device || !pCreateInfo || !pSampler)
        return NGFX_ERROR_INITIALIZATION_FAILED;
    if (!g_dispatch.CreateSampler)
        return NGFX_ERROR_INITIALIZATION_FAILED;
    return g_dispatch.CreateSampler(device, pCreateInfo, pSampler);
}

NGFX_API void ngfxDestroySampler(NGFX_Device device, NGFX_Sampler sampler) {
    if (device && sampler && g_dispatch.DestroySampler)
        g_dispatch.DestroySampler(device, sampler);
}
EOF