
// swr_common.c – shared utilities for software backend

#include "swr_common.h"
#include <stdlib.h>
#include <string.h>

int swr_ensure_command_space(SwrCommandBuffer* cmdBuf) {
    if (cmdBuf->count >= cmdBuf->capacity) {
        uint32_t newCap = cmdBuf->capacity * 2;
        SwrCommand* newCmds = (SwrCommand*)realloc(cmdBuf->commands, newCap * sizeof(SwrCommand));
        if (!newCmds) return 0;
        cmdBuf->commands = newCmds;
        cmdBuf->capacity = newCap;
    }
    return 1;
}

void* swr_copy_data(const void* src, size_t size) {
    void* dst = malloc(size);
    if (dst) memcpy(dst, src, size);
    return dst;
}