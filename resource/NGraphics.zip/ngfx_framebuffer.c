
// ngfx_framebuffer.c – framebuffer functions only

#include "ngraphics.h"
#include "ngfx_dispatch.h"

NGFX_API NGFX_Result ngfxCreateFramebuffer(NGFX_Device device,
                                           const NGFX_FramebufferCreateInfo* pCreateInfo,
                                           NGFX_Framebuffer* pFramebuffer) {
    if (!device || !pCreateInfo || !pFramebuffer)
        return NGFX_ERROR_INITIALIZATION_FAILED;
    if (!g_dispatch.CreateFramebuffer)
        return NGFX_ERROR_INITIALIZATION_FAILED;
    return g_dispatch.CreateFramebuffer(device, pCreateInfo, pFramebuffer);
}

NGFX_API void ngfxDestroyFramebuffer(NGFX_Device device, NGFX_Framebuffer framebuffer) {
    if (device && framebuffer && g_dispatch.DestroyFramebuffer)
        g_dispatch.DestroyFramebuffer(device, framebuffer);
}