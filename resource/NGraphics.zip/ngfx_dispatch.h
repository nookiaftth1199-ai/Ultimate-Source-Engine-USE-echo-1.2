
// ngfx_dispatch.h – dispatch table and backend loader declarations

#ifndef NGFX_DISPATCH_H
#define NGFX_DISPATCH_H

#include "ngraphics.h"

typedef struct NGFX_DispatchTable {
    // Instance
    NGFX_Result (*CreateInstance)(const NGFX_InstanceCreateInfo*, NGFX_Instance*);
    void        (*DestroyInstance)(NGFX_Instance);

    // Physical device
    NGFX_Result (*EnumeratePhysicalDevices)(NGFX_Instance, uint32_t*, NGFX_PhysicalDevice*);
    void        (*GetPhysicalDeviceProperties)(NGFX_PhysicalDevice, NGFX_PhysicalDeviceProperties*);

    // Device
    NGFX_Result (*CreateDevice)(NGFX_PhysicalDevice, const NGFX_DeviceCreateInfo*, NGFX_Device*);
    void        (*DestroyDevice)(NGFX_Device);
    void        (*GetDeviceQueue)(NGFX_Device, uint32_t, uint32_t, NGFX_Queue*);
    NGFX_Result (*DeviceWaitIdle)(NGFX_Device);

    // Command pool
    NGFX_Result (*CreateCommandPool)(NGFX_Device, const NGFX_CommandPoolCreateInfo*, NGFX_CommandPool*);
    void        (*DestroyCommandPool)(NGFX_Device, NGFX_CommandPool);

    // Command buffers
    NGFX_Result (*AllocateCommandBuffers)(NGFX_Device, const NGFX_CommandBufferAllocateInfo*, NGFX_CommandBuffer*);
    void        (*FreeCommandBuffers)(NGFX_Device, NGFX_CommandPool, uint32_t, const NGFX_CommandBuffer*);
    NGFX_Result (*BeginCommandBuffer)(NGFX_CommandBuffer, const NGFX_CommandBufferBeginInfo*);
    NGFX_Result (*EndCommandBuffer)(NGFX_CommandBuffer);
    NGFX_Result (*ResetCommandBuffer)(NGFX_CommandBuffer, NGFX_Flags);

    // Queue
    NGFX_Result (*QueueSubmit)(NGFX_Queue, uint32_t, const NGFX_SubmitInfo*, NGFX_Fence);
    NGFX_Result (*QueueWaitIdle)(NGFX_Queue);
    NGFX_Result (*QueuePresent)(NGFX_Queue, const void*);

    // Synchronization
    NGFX_Result (*CreateFence)(NGFX_Device, const NGFX_FenceCreateInfo*, NGFX_Fence*);
    void        (*DestroyFence)(NGFX_Device, NGFX_Fence);
    NGFX_Result (*WaitForFences)(NGFX_Device, uint32_t, const NGFX_Fence*, NGFX_Bool, uint64_t);
    NGFX_Result (*ResetFences)(NGFX_Device, uint32_t, const NGFX_Fence*);
    NGFX_Result (*CreateSemaphore)(NGFX_Device, const NGFX_SemaphoreCreateInfo*, NGFX_Semaphore*);
    void        (*DestroySemaphore)(NGFX_Device, NGFX_Semaphore);

    // Render pass
    NGFX_Result (*CreateRenderPass)(NGFX_Device, const NGFX_RenderPassCreateInfo*, NGFX_RenderPass*);
    void        (*DestroyRenderPass)(NGFX_Device, NGFX_RenderPass);

    // Framebuffer
    NGFX_Result (*CreateFramebuffer)(NGFX_Device, const NGFX_FramebufferCreateInfo*, NGFX_Framebuffer*);
    void        (*DestroyFramebuffer)(NGFX_Device, NGFX_Framebuffer);

    // Shader module
    NGFX_Result (*CreateShaderModule)(NGFX_Device, const NGFX_ShaderModuleCreateInfo*, NGFX_ShaderModule*);
    void        (*DestroyShaderModule)(NGFX_Device, NGFX_ShaderModule);

    // Pipeline layout
    NGFX_Result (*CreatePipelineLayout)(NGFX_Device, const NGFX_PipelineLayoutCreateInfo*, NGFX_PipelineLayout*);
    void        (*DestroyPipelineLayout)(NGFX_Device, NGFX_PipelineLayout);

    // Graphics pipeline
    NGFX_Result (*CreateGraphicsPipelines)(NGFX_Device, NGFX_PipelineCache, uint32_t,
                                           const NGFX_GraphicsPipelineCreateInfo*, NGFX_Pipeline*);
    void        (*DestroyPipeline)(NGFX_Device, NGFX_Pipeline);

    // Buffer
    NGFX_Result (*CreateBuffer)(NGFX_Device, const NGFX_BufferCreateInfo*, NGFX_Buffer*);
    void        (*DestroyBuffer)(NGFX_Device, NGFX_Buffer);

    // Image
    NGFX_Result (*CreateImage)(NGFX_Device, const NGFX_ImageCreateInfo*, NGFX_Image*);
    void        (*DestroyImage)(NGFX_Device, NGFX_Image);

    // Image view
    NGFX_Result (*CreateImageView)(NGFX_Device, const NGFX_ImageViewCreateInfo*, NGFX_ImageView*);
    void        (*DestroyImageView)(NGFX_Device, NGFX_ImageView);

    // Sampler
    NGFX_Result (*CreateSampler)(NGFX_Device, const NGFX_SamplerCreateInfo*, NGFX_Sampler*);
    void        (*DestroySampler)(NGFX_Device, NGFX_Sampler);

    // Commands
    void (*CmdBeginRenderPass)(NGFX_CommandBuffer, const void*, uint32_t);
    void (*CmdEndRenderPass)(NGFX_CommandBuffer);
    void (*CmdBindPipeline)(NGFX_CommandBuffer, NGFX_PipelineBindPoint, NGFX_Pipeline);
    void (*CmdBindVertexBuffers)(NGFX_CommandBuffer, uint32_t, uint32_t, const NGFX_Buffer*, const NGFX_DeviceSize*);
    void (*CmdBindIndexBuffer)(NGFX_CommandBuffer, NGFX_Buffer, NGFX_DeviceSize, NGFX_IndexType);
    void (*CmdDraw)(NGFX_CommandBuffer, uint32_t, uint32_t, uint32_t, uint32_t);
    void (*CmdDrawIndexed)(NGFX_CommandBuffer, uint32_t, uint32_t, uint32_t, int32_t, uint32_t);
    void (*CmdSetViewport)(NGFX_CommandBuffer, uint32_t, uint32_t, const NGFX_Viewport*);
    void (*CmdSetScissor)(NGFX_CommandBuffer, uint32_t, uint32_t, const NGFX_Rect2D*);

    // Surface and swapchain
    NGFX_Result (*CreateSurface)(NGFX_Instance, const void*, NGFX_Surface*);
    void        (*DestroySurface)(NGFX_Instance, NGFX_Surface);
    NGFX_Result (*GetPhysicalDeviceSurfaceSupport)(NGFX_PhysicalDevice, uint32_t, NGFX_Surface, NGFX_Bool*);
    NGFX_Result (*CreateSwapchain)(NGFX_Device, const NGFX_SwapchainCreateInfo*, NGFX_Swapchain*);
    void        (*DestroySwapchain)(NGFX_Device, NGFX_Swapchain);
    NGFX_Result (*GetSwapchainImages)(NGFX_Device, NGFX_Swapchain, uint32_t*, NGFX_Image*);
    NGFX_Result (*AcquireNextImage)(NGFX_Device, NGFX_Swapchain, uint64_t, NGFX_Semaphore, NGFX_Fence, uint32_t*);
} NGFX_DispatchTable;

typedef enum NGFX_BackendType {
    NGFX_BACKEND_SOFTWARE,
    NGFX_BACKEND_VULKAN,
    NGFX_BACKEND_COUNT
} NGFX_BackendType;

extern NGFX_DispatchTable g_dispatch;

NGFX_Result ngfxLoadBackend(NGFX_BackendType type);

#endif // NGFX_DISPATCH_H