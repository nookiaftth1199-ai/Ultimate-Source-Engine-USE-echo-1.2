
// ngfx_sync.c – synchronization functions (fences, semaphores)

#include "ngraphics.h"
#include "ngfx_dispatch.h"

NGFX_API NGFX_Result ngfxCreateFence(NGFX_Device device,
                                     const NGFX_FenceCreateInfo* pCreateInfo,
                                     NGFX_Fence* pFence) {
    if (!device || !pCreateInfo || !pFence)
        return NGFX_ERROR_INITIALIZATION_FAILED;
    if (!g_dispatch.CreateFence)
        return NGFX_ERROR_INITIALIZATION_FAILED;
    return g_dispatch.CreateFence(device, pCreateInfo, pFence);
}

NGFX_API void ngfxDestroyFence(NGFX_Device device, NGFX_Fence fence) {
    if (device && fence && g_dispatch.DestroyFence)
        g_dispatch.DestroyFence(device, fence);
}

NGFX_API NGFX_Result ngfxWaitForFences(NGFX_Device device,
                                       uint32_t fenceCount,
                                       const NGFX_Fence* pFences,
                                       NGFX_Bool waitAll,
                                       uint64_t timeout) {
    if (!device || fenceCount == 0 || !pFences)
        return NGFX_ERROR_INITIALIZATION_FAILED;
    if (!g_dispatch.WaitForFences)
        return NGFX_ERROR_INITIALIZATION_FAILED;
    return g_dispatch.WaitForFences(device, fenceCount, pFences, waitAll, timeout);
}

NGFX_API NGFX_Result ngfxResetFences(NGFX_Device device,
                                     uint32_t fenceCount,
                                     const NGFX_Fence* pFences) {
    if (!device || fenceCount == 0 || !pFences)
        return NGFX_ERROR_INITIALIZATION_FAILED;
    if (!g_dispatch.ResetFences)
        return NGFX_ERROR_INITIALIZATION_FAILED;
    return g_dispatch.ResetFences(device, fenceCount, pFences);
}

NGFX_API NGFX_Result ngfxCreateSemaphore(NGFX_Device device,
                                         const NGFX_SemaphoreCreateInfo* pCreateInfo,
                                         NGFX_Semaphore* pSemaphore) {
    if (!device || !pCreateInfo || !pSemaphore)
        return NGFX_ERROR_INITIALIZATION_FAILED;
    if (!g_dispatch.CreateSemaphore)
        return NGFX_ERROR_INITIALIZATION_FAILED;
    return g_dispatch.CreateSemaphore(device, pCreateInfo, pSemaphore);
}

NGFX_API void ngfxDestroySemaphore(NGFX_Device device, NGFX_Semaphore semaphore) {
    if (device && semaphore && g_dispatch.DestroySemaphore)
        g_dispatch.DestroySemaphore(device, semaphore);
}