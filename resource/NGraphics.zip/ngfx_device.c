cat > ngfx_device.c << 'EOF'
// ngfx_device.c – device functions

#include "ngraphics.h"
#include "ngfx_dispatch.h"

NGFX_API NGFX_Result ngfxCreateDevice(NGFX_PhysicalDevice physicalDevice,
                                      const NGFX_DeviceCreateInfo* pCreateInfo,
                                      NGFX_Device* pDevice) {
    if (!physicalDevice || !pCreateInfo || !pDevice)
        return NGFX_ERROR_INITIALIZATION_FAILED;
    if (!g_dispatch.CreateDevice)
        return NGFX_ERROR_INITIALIZATION_FAILED;
    return g_dispatch.CreateDevice(physicalDevice, pCreateInfo, pDevice);
}

NGFX_API void ngfxDestroyDevice(NGFX_Device device) {
    if (device && g_dispatch.DestroyDevice)
        g_dispatch.DestroyDevice(device);
}

NGFX_API void ngfxGetDeviceQueue(NGFX_Device device,
                                 uint32_t queueFamilyIndex,
                                 uint32_t queueIndex,
                                 NGFX_Queue* pQueue) {
    if (device && pQueue && g_dispatch.GetDeviceQueue)
        g_dispatch.GetDeviceQueue(device, queueFamilyIndex, queueIndex, pQueue);
}

NGFX_API NGFX_Result ngfxDeviceWaitIdle(NGFX_Device device) {
    if (!device) return NGFX_ERROR_INITIALIZATION_FAILED;
    if (!g_dispatch.DeviceWaitIdle) return NGFX_ERROR_INITIALIZATION_FAILED;
    return g_dispatch.DeviceWaitIdle(device);
}
EOF