
// ngraphics.h – complete, corrected
#ifndef NGRAPHICS_H
#define NGRAPHICS_H

#ifdef __cplusplus
extern "C" {
#endif

//=============================================================================
// Versioning
//=============================================================================
#define NGFX_VERSION_MAJOR 1
#define NGFX_VERSION_MINOR 0
#define NGFX_VERSION_PATCH 0
#define NGFX_API_VERSION    ((NGFX_VERSION_MAJOR << 22) | (NGFX_VERSION_MINOR << 12) | NGFX_VERSION_PATCH)

//=============================================================================
// DLL Export/Import (Windows)
//=============================================================================
#ifdef _WIN32
    #ifdef NGFX_EXPORTS
        #define NGFX_API __declspec(dllexport)
    #else
        #define NGFX_API __declspec(dllimport)
    #endif
#else
    #define NGFX_API
#endif

//=============================================================================
// Basic Types
//=============================================================================
#include <stdint.h>

typedef uint8_t  NGFX_Bool;
#define NGFX_FALSE 0
#define NGFX_TRUE  1

typedef uint32_t NGFX_Flags;
typedef uint64_t NGFX_DeviceSize;

// Opaque handles
typedef struct NGFX_Instance_T*          NGFX_Instance;
typedef struct NGFX_PhysicalDevice_T*    NGFX_PhysicalDevice;
typedef struct NGFX_Device_T*            NGFX_Device;
typedef struct NGFX_Queue_T*             NGFX_Queue;
typedef struct NGFX_CommandPool_T*       NGFX_CommandPool;
typedef struct NGFX_CommandBuffer_T*     NGFX_CommandBuffer;
typedef struct NGFX_RenderPass_T*        NGFX_RenderPass;
typedef struct NGFX_Framebuffer_T*       NGFX_Framebuffer;
typedef struct NGFX_Pipeline_T*          NGFX_Pipeline;
typedef struct NGFX_PipelineLayout_T*    NGFX_PipelineLayout;
typedef struct NGFX_ShaderModule_T*      NGFX_ShaderModule;
typedef struct NGFX_Buffer_T*            NGFX_Buffer;
typedef struct NGFX_Image_T*             NGFX_Image;
typedef struct NGFX_ImageView_T*         NGFX_ImageView;
typedef struct NGFX_Sampler_T*           NGFX_Sampler;
typedef struct NGFX_Fence_T*             NGFX_Fence;
typedef struct NGFX_Semaphore_T*         NGFX_Semaphore;
typedef struct NGFX_Surface_T*           NGFX_Surface;
typedef struct NGFX_Swapchain_T*         NGFX_Swapchain;
typedef struct NGFX_PipelineCache_T*     NGFX_PipelineCache;

#define NGFX_NULL_HANDLE ((void*)0)

//=============================================================================
// Result Codes
//=============================================================================
typedef enum NGFX_Result {
    NGFX_SUCCESS = 0,
    NGFX_ERROR_OUT_OF_HOST_MEMORY = -1,
    NGFX_ERROR_OUT_OF_DEVICE_MEMORY = -2,
    NGFX_ERROR_INITIALIZATION_FAILED = -3,
    NGFX_ERROR_DEVICE_LOST = -4,
    NGFX_ERROR_MEMORY_MAP_FAILED = -5,
    NGFX_ERROR_LAYER_NOT_PRESENT = -6,
    NGFX_ERROR_EXTENSION_NOT_PRESENT = -7,
    NGFX_ERROR_FEATURE_NOT_PRESENT = -8,
    NGFX_ERROR_INCOMPATIBLE_DRIVER = -9,
    NGFX_ERROR_TOO_MANY_OBJECTS = -10,
    NGFX_ERROR_FORMAT_NOT_SUPPORTED = -11,
    NGFX_ERROR_FRAGMENTED_POOL = -12,
    NGFX_ERROR_SURFACE_LOST = -13,
    NGFX_ERROR_NATIVE_WINDOW_IN_USE = -14,
    NGFX_ERROR_OUT_OF_DATE = -15,
    NGFX_ERROR_INCOMPATIBLE_DISPLAY = -16,
    NGFX_ERROR_VALIDATION_FAILED = -17,
    NGFX_ERROR_INVALID_SHADER = -18,
    NGFX_ERROR_INCOMPATIBLE_SHADER = -19,
    NGFX_RESULT_MAX_ENUM = 0x7FFFFFFF
} NGFX_Result;

//=============================================================================
// Enumerations
//=============================================================================

typedef enum NGFX_StructureType {
    NGFX_STRUCTURE_TYPE_APPLICATION_INFO = 0,
    NGFX_STRUCTURE_TYPE_INSTANCE_CREATE_INFO,
    NGFX_STRUCTURE_TYPE_DEVICE_QUEUE_CREATE_INFO,
    NGFX_STRUCTURE_TYPE_DEVICE_CREATE_INFO,
    NGFX_STRUCTURE_TYPE_COMMAND_POOL_CREATE_INFO,
    NGFX_STRUCTURE_TYPE_COMMAND_BUFFER_ALLOCATE_INFO,
    NGFX_STRUCTURE_TYPE_COMMAND_BUFFER_BEGIN_INFO,
    NGFX_STRUCTURE_TYPE_RENDER_PASS_CREATE_INFO,
    NGFX_STRUCTURE_TYPE_FRAMEBUFFER_CREATE_INFO,
    NGFX_STRUCTURE_TYPE_GRAPHICS_PIPELINE_CREATE_INFO,
    NGFX_STRUCTURE_TYPE_PIPELINE_LAYOUT_CREATE_INFO,
    NGFX_STRUCTURE_TYPE_SHADER_MODULE_CREATE_INFO,
    NGFX_STRUCTURE_TYPE_BUFFER_CREATE_INFO,
    NGFX_STRUCTURE_TYPE_IMAGE_CREATE_INFO,
    NGFX_STRUCTURE_TYPE_IMAGE_VIEW_CREATE_INFO,
    NGFX_STRUCTURE_TYPE_SAMPLER_CREATE_INFO,
    NGFX_STRUCTURE_TYPE_FENCE_CREATE_INFO,
    NGFX_STRUCTURE_TYPE_SEMAPHORE_CREATE_INFO,
    NGFX_STRUCTURE_TYPE_SUBMIT_INFO,
    NGFX_STRUCTURE_TYPE_SWAPCHAIN_CREATE_INFO,
    NGFX_STRUCTURE_TYPE_WIN32_SURFACE_CREATE_INFO,
    NGFX_STRUCTURE_TYPE_MAX_ENUM = 0x7FFFFFFF
} NGFX_StructureType;

typedef enum NGFX_Format {
    NGFX_FORMAT_UNDEFINED = 0,
    NGFX_FORMAT_R8G8B8A8_UNORM,
    NGFX_FORMAT_B8G8R8A8_UNORM,
    NGFX_FORMAT_R32G32B32A32_SFLOAT,
    NGFX_FORMAT_R32G32B32_SFLOAT,
    NGFX_FORMAT_R32G32_SFLOAT,
    NGFX_FORMAT_R32_SFLOAT,
    NGFX_FORMAT_D32_SFLOAT,
    NGFX_FORMAT_D24_UNORM_S8_UINT,
    NGFX_FORMAT_MAX_ENUM = 0x7FFFFFFF
} NGFX_Format;

typedef enum NGFX_ImageLayout {
    NGFX_IMAGE_LAYOUT_UNDEFINED = 0,
    NGFX_IMAGE_LAYOUT_GENERAL,
    NGFX_IMAGE_LAYOUT_COLOR_ATTACHMENT_OPTIMAL,
    NGFX_IMAGE_LAYOUT_DEPTH_STENCIL_ATTACHMENT_OPTIMAL,
    NGFX_IMAGE_LAYOUT_DEPTH_STENCIL_READ_ONLY_OPTIMAL,
    NGFX_IMAGE_LAYOUT_SHADER_READ_ONLY_OPTIMAL,
    NGFX_IMAGE_LAYOUT_TRANSFER_SRC_OPTIMAL,
    NGFX_IMAGE_LAYOUT_TRANSFER_DST_OPTIMAL,
    NGFX_IMAGE_LAYOUT_PREINITIALIZED,
    NGFX_IMAGE_LAYOUT_PRESENT_SRC,
    NGFX_IMAGE_LAYOUT_MAX_ENUM = 0x7FFFFFFF
} NGFX_ImageLayout;

typedef enum NGFX_AttachmentLoadOp {
    NGFX_ATTACHMENT_LOAD_OP_LOAD = 0,
    NGFX_ATTACHMENT_LOAD_OP_CLEAR,
    NGFX_ATTACHMENT_LOAD_OP_DONT_CARE,
    NGFX_ATTACHMENT_LOAD_OP_MAX_ENUM = 0x7FFFFFFF
} NGFX_AttachmentLoadOp;

typedef enum NGFX_AttachmentStoreOp {
    NGFX_ATTACHMENT_STORE_OP_STORE = 0,
    NGFX_ATTACHMENT_STORE_OP_DONT_CARE,
    NGFX_ATTACHMENT_STORE_OP_MAX_ENUM = 0x7FFFFFFF
} NGFX_AttachmentStoreOp;

typedef enum NGFX_PipelineBindPoint {
    NGFX_PIPELINE_BIND_POINT_GRAPHICS = 0,
    NGFX_PIPELINE_BIND_POINT_COMPUTE,
    NGFX_PIPELINE_BIND_POINT_MAX_ENUM = 0x7FFFFFFF
} NGFX_PipelineBindPoint;

typedef enum NGFX_PrimitiveTopology {
    NGFX_PRIMITIVE_TOPOLOGY_POINT_LIST = 0,
    NGFX_PRIMITIVE_TOPOLOGY_LINE_LIST,
    NGFX_PRIMITIVE_TOPOLOGY_LINE_STRIP,
    NGFX_PRIMITIVE_TOPOLOGY_TRIANGLE_LIST,
    NGFX_PRIMITIVE_TOPOLOGY_TRIANGLE_STRIP,
    NGFX_PRIMITIVE_TOPOLOGY_TRIANGLE_FAN,
    NGFX_PRIMITIVE_TOPOLOGY_MAX_ENUM = 0x7FFFFFFF
} NGFX_PrimitiveTopology;

typedef enum NGFX_PolygonMode {
    NGFX_POLYGON_MODE_FILL = 0,
    NGFX_POLYGON_MODE_LINE,
    NGFX_POLYGON_MODE_POINT,
    NGFX_POLYGON_MODE_MAX_ENUM = 0x7FFFFFFF
} NGFX_PolygonMode;

typedef enum NGFX_CullModeFlagBits {
    NGFX_CULL_MODE_NONE = 0,
    NGFX_CULL_MODE_FRONT_BIT = 1 << 0,
    NGFX_CULL_MODE_BACK_BIT = 1 << 1,
    NGFX_CULL_MODE_FRONT_AND_BACK = 0x3,
    NGFX_CULL_MODE_FLAG_BITS_MAX_ENUM = 0x7FFFFFFF
} NGFX_CullModeFlagBits;
typedef uint32_t NGFX_CullModeFlags;

typedef enum NGFX_FrontFace {
    NGFX_FRONT_FACE_COUNTER_CLOCKWISE = 0,
    NGFX_FRONT_FACE_CLOCKWISE,
    NGFX_FRONT_FACE_MAX_ENUM = 0x7FFFFFFF
} NGFX_FrontFace;

typedef enum NGFX_CompareOp {
    NGFX_COMPARE_OP_NEVER = 0,
    NGFX_COMPARE_OP_LESS,
    NGFX_COMPARE_OP_EQUAL,
    NGFX_COMPARE_OP_LESS_OR_EQUAL,
    NGFX_COMPARE_OP_GREATER,
    NGFX_COMPARE_OP_NOT_EQUAL,
    NGFX_COMPARE_OP_GREATER_OR_EQUAL,
    NGFX_COMPARE_OP_ALWAYS,
    NGFX_COMPARE_OP_MAX_ENUM = 0x7FFFFFFF
} NGFX_CompareOp;

typedef enum NGFX_StencilOp {
    NGFX_STENCIL_OP_KEEP = 0,
    NGFX_STENCIL_OP_ZERO,
    NGFX_STENCIL_OP_REPLACE,
    NGFX_STENCIL_OP_INCREMENT_AND_CLAMP,
    NGFX_STENCIL_OP_DECREMENT_AND_CLAMP,
    NGFX_STENCIL_OP_INVERT,
    NGFX_STENCIL_OP_INCREMENT_AND_WRAP,
    NGFX_STENCIL_OP_DECREMENT_AND_WRAP,
    NGFX_STENCIL_OP_MAX_ENUM = 0x7FFFFFFF
} NGFX_StencilOp;

typedef enum NGFX_BlendFactor {
    NGFX_BLEND_FACTOR_ZERO = 0,
    NGFX_BLEND_FACTOR_ONE,
    NGFX_BLEND_FACTOR_SRC_COLOR,
    NGFX_BLEND_FACTOR_ONE_MINUS_SRC_COLOR,
    NGFX_BLEND_FACTOR_DST_COLOR,
    NGFX_BLEND_FACTOR_ONE_MINUS_DST_COLOR,
    NGFX_BLEND_FACTOR_SRC_ALPHA,
    NGFX_BLEND_FACTOR_ONE_MINUS_SRC_ALPHA,
    NGFX_BLEND_FACTOR_DST_ALPHA,
    NGFX_BLEND_FACTOR_ONE_MINUS_DST_ALPHA,
    NGFX_BLEND_FACTOR_CONSTANT_COLOR,
    NGFX_BLEND_FACTOR_ONE_MINUS_CONSTANT_COLOR,
    NGFX_BLEND_FACTOR_CONSTANT_ALPHA,
    NGFX_BLEND_FACTOR_ONE_MINUS_CONSTANT_ALPHA,
    NGFX_BLEND_FACTOR_SRC_ALPHA_SATURATE,
    NGFX_BLEND_FACTOR_SRC1_COLOR,
    NGFX_BLEND_FACTOR_ONE_MINUS_SRC1_COLOR,
    NGFX_BLEND_FACTOR_SRC1_ALPHA,
    NGFX_BLEND_FACTOR_ONE_MINUS_SRC1_ALPHA,
    NGFX_BLEND_FACTOR_MAX_ENUM = 0x7FFFFFFF
} NGFX_BlendFactor;

typedef enum NGFX_BlendOp {
    NGFX_BLEND_OP_ADD = 0,
    NGFX_BLEND_OP_SUBTRACT,
    NGFX_BLEND_OP_REVERSE_SUBTRACT,
    NGFX_BLEND_OP_MIN,
    NGFX_BLEND_OP_MAX,
    NGFX_BLEND_OP_MAX_ENUM = 0x7FFFFFFF
} NGFX_BlendOp;

typedef enum NGFX_IndexType {
    NGFX_INDEX_TYPE_UINT16 = 0,
    NGFX_INDEX_TYPE_UINT32,
    NGFX_INDEX_TYPE_MAX_ENUM = 0x7FFFFFFF
} NGFX_IndexType;

typedef enum NGFX_Filter {
    NGFX_FILTER_NEAREST = 0,
    NGFX_FILTER_LINEAR,
    NGFX_FILTER_MAX_ENUM = 0x7FFFFFFF
} NGFX_Filter;

typedef enum NGFX_SamplerAddressMode {
    NGFX_SAMPLER_ADDRESS_MODE_REPEAT = 0,
    NGFX_SAMPLER_ADDRESS_MODE_MIRRORED_REPEAT,
    NGFX_SAMPLER_ADDRESS_MODE_CLAMP_TO_EDGE,
    NGFX_SAMPLER_ADDRESS_MODE_CLAMP_TO_BORDER,
    NGFX_SAMPLER_ADDRESS_MODE_MIRROR_CLAMP_TO_EDGE,
    NGFX_SAMPLER_ADDRESS_MODE_MAX_ENUM = 0x7FFFFFFF
} NGFX_SamplerAddressMode;

typedef enum NGFX_BorderColor {
    NGFX_BORDER_COLOR_FLOAT_TRANSPARENT_BLACK = 0,
    NGFX_BORDER_COLOR_INT_TRANSPARENT_BLACK,
    NGFX_BORDER_COLOR_FLOAT_OPAQUE_BLACK,
    NGFX_BORDER_COLOR_INT_OPAQUE_BLACK,
    NGFX_BORDER_COLOR_FLOAT_OPAQUE_WHITE,
    NGFX_BORDER_COLOR_INT_OPAQUE_WHITE,
    NGFX_BORDER_COLOR_MAX_ENUM = 0x7FFFFFFF
} NGFX_BorderColor;

typedef enum NGFX_ShaderStageFlagBits {
    NGFX_SHADER_STAGE_VERTEX_BIT = 1 << 0,
    NGFX_SHADER_STAGE_FRAGMENT_BIT = 1 << 1,
    NGFX_SHADER_STAGE_COMPUTE_BIT = 1 << 2,
    NGFX_SHADER_STAGE_ALL_GRAPHICS = 0x3,
    NGFX_SHADER_STAGE_ALL = 0x7FFFFFFF
} NGFX_ShaderStageFlagBits;
typedef uint32_t NGFX_ShaderStageFlags;

typedef enum NGFX_SubpassContents {
    NGFX_SUBPASS_CONTENTS_INLINE = 0,
    NGFX_SUBPASS_CONTENTS_SECONDARY_COMMAND_BUFFERS,
    NGFX_SUBPASS_CONTENTS_MAX_ENUM = 0x7FFFFFFF
} NGFX_SubpassContents;

//=============================================================================
// Structures
//=============================================================================

typedef struct NGFX_ApplicationInfo {
    const char*     pApplicationName;
    uint32_t        applicationVersion;
    const char*     pEngineName;
    uint32_t        engineVersion;
    uint32_t        apiVersion;
} NGFX_ApplicationInfo;

typedef struct NGFX_InstanceCreateInfo {
    const NGFX_ApplicationInfo* pApplicationInfo;
    uint32_t                    enabledLayerCount;
    const char* const*          ppEnabledLayerNames;
    uint32_t                    enabledExtensionCount;
    const char* const*          ppEnabledExtensionNames;
} NGFX_InstanceCreateInfo;

typedef struct NGFX_PhysicalDeviceProperties {
    char        deviceName[256];
    uint32_t    apiVersion;
    uint32_t    driverVersion;
    uint32_t    vendorID;
    uint32_t    deviceID;
    uint32_t    deviceType; // 0 = other, 1 = integrated, 2 = discrete, 3 = virtual, 4 = cpu
} NGFX_PhysicalDeviceProperties;

typedef struct NGFX_DeviceQueueCreateInfo {
    uint32_t            queueFamilyIndex;
    uint32_t            queueCount;
    const float*        pQueuePriorities;
} NGFX_DeviceQueueCreateInfo;

typedef struct NGFX_DeviceCreateInfo {
    uint32_t                           queueCreateInfoCount;
    const NGFX_DeviceQueueCreateInfo*  pQueueCreateInfos;
    uint32_t                           enabledLayerCount;
    const char* const*                  ppEnabledLayerNames;
    uint32_t                           enabledExtensionCount;
    const char* const*                  ppEnabledExtensionNames;
    const void*                         pNext;
} NGFX_DeviceCreateInfo;

typedef struct NGFX_CommandPoolCreateInfo {
    uint32_t                queueFamilyIndex;
    NGFX_Flags              flags;
} NGFX_CommandPoolCreateInfo;

typedef struct NGFX_CommandBufferAllocateInfo {
    NGFX_CommandPool        commandPool;
    uint32_t                level;
    uint32_t                commandBufferCount;
} NGFX_CommandBufferAllocateInfo;

typedef struct NGFX_CommandBufferBeginInfo {
    NGFX_Flags              flags;
} NGFX_CommandBufferBeginInfo;

typedef struct NGFX_SubmitInfo {
    uint32_t                waitSemaphoreCount;
    const NGFX_Semaphore*   pWaitSemaphores;
    const uint32_t*         pWaitDstStageMask;
    uint32_t                commandBufferCount;
    const NGFX_CommandBuffer* pCommandBuffers;
    uint32_t                signalSemaphoreCount;
    const NGFX_Semaphore*   pSignalSemaphores;
} NGFX_SubmitInfo;

typedef struct NGFX_FenceCreateInfo {
    NGFX_Flags              flags;
} NGFX_FenceCreateInfo;

typedef struct NGFX_SemaphoreCreateInfo {
    NGFX_Flags              flags;
} NGFX_SemaphoreCreateInfo;

typedef struct NGFX_AttachmentDescription {
    NGFX_Format             format;
    uint32_t                samples;
    NGFX_AttachmentLoadOp   loadOp;
    NGFX_AttachmentStoreOp  storeOp;
    NGFX_AttachmentLoadOp   stencilLoadOp;
    NGFX_AttachmentStoreOp  stencilStoreOp;
    NGFX_ImageLayout        initialLayout;
    NGFX_ImageLayout        finalLayout;
} NGFX_AttachmentDescription;

typedef struct NGFX_AttachmentReference {
    uint32_t                attachment;
    NGFX_ImageLayout        layout;
} NGFX_AttachmentReference;

typedef struct NGFX_SubpassDescription {
    NGFX_PipelineBindPoint  pipelineBindPoint;
    uint32_t                inputAttachmentCount;
    const NGFX_AttachmentReference* pInputAttachments;
    uint32_t                colorAttachmentCount;
    const NGFX_AttachmentReference* pColorAttachments;
    const NGFX_AttachmentReference* pResolveAttachments;
    const NGFX_AttachmentReference* pDepthStencilAttachment;
    uint32_t                preserveAttachmentCount;
    const uint32_t*         pPreserveAttachments;
} NGFX_SubpassDescription;

typedef struct NGFX_SubpassDependency {
    uint32_t                srcSubpass;
    uint32_t                dstSubpass;
    uint32_t                srcStageMask;
    uint32_t                dstStageMask;
    uint32_t                srcAccessMask;
    uint32_t                dstAccessMask;
} NGFX_SubpassDependency;

typedef struct NGFX_RenderPassCreateInfo {
    uint32_t                        attachmentCount;
    const NGFX_AttachmentDescription* pAttachments;
    uint32_t                        subpassCount;
    const NGFX_SubpassDescription*   pSubpasses;
    uint32_t                        dependencyCount;
    const NGFX_SubpassDependency*     pDependencies;
} NGFX_RenderPassCreateInfo;

typedef struct NGFX_FramebufferCreateInfo {
    NGFX_RenderPass             renderPass;
    uint32_t                    attachmentCount;
    const NGFX_ImageView*       pAttachments;
    uint32_t                    width;
    uint32_t                    height;
    uint32_t                    layers;
} NGFX_FramebufferCreateInfo;

typedef struct NGFX_ShaderModuleCreateInfo {
    uint32_t                    codeSize;
    const uint32_t*             pCode;
} NGFX_ShaderModuleCreateInfo;

typedef struct NGFX_PipelineShaderStageCreateInfo {
    NGFX_ShaderStageFlags       stage;
    NGFX_ShaderModule           module;
    const char*                 pName;
} NGFX_PipelineShaderStageCreateInfo;

typedef struct NGFX_VertexInputBindingDescription {
    uint32_t                    binding;
    uint32_t                    stride;
    uint32_t                    inputRate;
} NGFX_VertexInputBindingDescription;

typedef struct NGFX_VertexInputAttributeDescription {
    uint32_t                    location;
    uint32_t                    binding;
    NGFX_Format                 format;
    uint32_t                    offset;
} NGFX_VertexInputAttributeDescription;

typedef struct NGFX_PipelineVertexInputStateCreateInfo {
    uint32_t                                   vertexBindingDescriptionCount;
    const NGFX_VertexInputBindingDescription*  pVertexBindingDescriptions;
    uint32_t                                   vertexAttributeDescriptionCount;
    const NGFX_VertexInputAttributeDescription* pVertexAttributeDescriptions;
} NGFX_PipelineVertexInputStateCreateInfo;

typedef struct NGFX_PipelineInputAssemblyStateCreateInfo {
    NGFX_PrimitiveTopology      topology;
    NGFX_Bool                   primitiveRestartEnable;
} NGFX_PipelineInputAssemblyStateCreateInfo;

typedef struct NGFX_Viewport {
    float x;
    float y;
    float width;
    float height;
    float minDepth;
    float maxDepth;
} NGFX_Viewport;

typedef struct NGFX_Rect2D {
    int32_t x;
    int32_t y;
    uint32_t width;
    uint32_t height;
} NGFX_Rect2D;

typedef struct NGFX_PipelineViewportStateCreateInfo {
    uint32_t                    viewportCount;
    const NGFX_Viewport*        pViewports;
    uint32_t                    scissorCount;
    const NGFX_Rect2D*          pScissors;
} NGFX_PipelineViewportStateCreateInfo;

typedef struct NGFX_PipelineRasterizationStateCreateInfo {
    NGFX_Bool                   depthClampEnable;
    NGFX_Bool                   rasterizerDiscardEnable;
    NGFX_PolygonMode            polygonMode;
    NGFX_CullModeFlags          cullMode;
    NGFX_FrontFace              frontFace;
    NGFX_Bool                   depthBiasEnable;
    float                       depthBiasConstantFactor;
    float                       depthBiasClamp;
    float                       depthBiasSlopeFactor;
    float                       lineWidth;
} NGFX_PipelineRasterizationStateCreateInfo;

typedef struct NGFX_PipelineMultisampleStateCreateInfo {
    uint32_t                    rasterizationSamples;
    NGFX_Bool                   sampleShadingEnable;
    float                       minSampleShading;
} NGFX_PipelineMultisampleStateCreateInfo;

typedef struct NGFX_StencilOpState {
    NGFX_StencilOp              failOp;
    NGFX_StencilOp              passOp;
    NGFX_StencilOp              depthFailOp;
    NGFX_CompareOp              compareOp;
    uint32_t                    compareMask;
    uint32_t                    writeMask;
    uint32_t                    reference;
} NGFX_StencilOpState;

typedef struct NGFX_PipelineDepthStencilStateCreateInfo {
    NGFX_Bool                   depthTestEnable;
    NGFX_Bool                   depthWriteEnable;
    NGFX_CompareOp              depthCompareOp;
    NGFX_Bool                   depthBoundsTestEnable;
    NGFX_Bool                   stencilTestEnable;
    NGFX_StencilOpState         front;
    NGFX_StencilOpState         back;
    float                       minDepthBounds;
    float                       maxDepthBounds;
} NGFX_PipelineDepthStencilStateCreateInfo;

typedef struct NGFX_PipelineColorBlendAttachmentState {
    NGFX_Bool                   blendEnable;
    NGFX_BlendFactor            srcColorBlendFactor;
    NGFX_BlendFactor            dstColorBlendFactor;
    NGFX_BlendOp                colorBlendOp;
    NGFX_BlendFactor            srcAlphaBlendFactor;
    NGFX_BlendFactor            dstAlphaBlendFactor;
    NGFX_BlendOp                alphaBlendOp;
    uint32_t                    colorWriteMask;
} NGFX_PipelineColorBlendAttachmentState;

typedef struct NGFX_PipelineColorBlendStateCreateInfo {
    NGFX_Bool                   logicOpEnable;
    uint32_t                    logicOp;
    uint32_t                    attachmentCount;
    const NGFX_PipelineColorBlendAttachmentState* pAttachments;
    float                       blendConstants[4];
} NGFX_PipelineColorBlendStateCreateInfo;

typedef struct NGFX_PipelineLayoutCreateInfo {
    uint32_t                    setLayoutCount;
    const void**                pSetLayouts;
    uint32_t                    pushConstantRangeCount;
} NGFX_PipelineLayoutCreateInfo;

typedef struct NGFX_GraphicsPipelineCreateInfo {
    uint32_t                                    stageCount;
    const NGFX_PipelineShaderStageCreateInfo*   pStages;
    const NGFX_PipelineVertexInputStateCreateInfo* pVertexInputState;
    const NGFX_PipelineInputAssemblyStateCreateInfo* pInputAssemblyState;
    const NGFX_PipelineViewportStateCreateInfo* pViewportState;
    const NGFX_PipelineRasterizationStateCreateInfo* pRasterizationState;
    const NGFX_PipelineMultisampleStateCreateInfo* pMultisampleState;
    const NGFX_PipelineDepthStencilStateCreateInfo* pDepthStencilState;
    const NGFX_PipelineColorBlendStateCreateInfo* pColorBlendState;
    const void*                                 pDynamicState;
    NGFX_PipelineLayout                         layout;
    NGFX_RenderPass                              renderPass;
    uint32_t                                     subpass;
    NGFX_Pipeline                                 basePipelineHandle;
    int32_t                                       basePipelineIndex;
} NGFX_GraphicsPipelineCreateInfo;

typedef struct NGFX_BufferCreateInfo {
    NGFX_DeviceSize             size;
    uint32_t                    usage;
    uint32_t                    sharingMode;
} NGFX_BufferCreateInfo;

typedef struct NGFX_ImageCreateInfo {
    uint32_t                    imageType;
    NGFX_Format                 format;
    uint32_t                    extent_width;
    uint32_t                    extent_height;
    uint32_t                    extent_depth;
    uint32_t                    mipLevels;
    uint32_t                    arrayLayers;
    uint32_t                    samples;
    uint32_t                    tiling;
    uint32_t                    usage;
    uint32_t                    sharingMode;
    uint32_t                    initialLayout;
} NGFX_ImageCreateInfo;

typedef struct NGFX_ImageViewCreateInfo {
    NGFX_Image                  image;
    uint32_t                    viewType;
    NGFX_Format                 format;
    uint32_t                    components;
    uint32_t                    subresourceRange_aspectMask;
    uint32_t                    subresourceRange_baseMipLevel;
    uint32_t                    subresourceRange_levelCount;
    uint32_t                    subresourceRange_baseArrayLayer;
    uint32_t                    subresourceRange_layerCount;
} NGFX_ImageViewCreateInfo;

typedef struct NGFX_SamplerCreateInfo {
    NGFX_Filter                 magFilter;
    NGFX_Filter                 minFilter;
    uint32_t                    mipmapMode;
    NGFX_SamplerAddressMode     addressModeU;
    NGFX_SamplerAddressMode     addressModeV;
    NGFX_SamplerAddressMode     addressModeW;
    float                       mipLodBias;
    NGFX_Bool                   anisotropyEnable;
    float                       maxAnisotropy;
    NGFX_Bool                   compareEnable;
    NGFX_CompareOp              compareOp;
    float                       minLod;
    float                       maxLod;
    NGFX_BorderColor            borderColor;
    NGFX_Bool                   unnormalizedCoordinates;
} NGFX_SamplerCreateInfo;

//=============================================================================
// Clear value, render pass begin, present info
//=============================================================================

typedef union NGFX_ClearValue {
    float color[4];
    struct { float depth; uint32_t stencil; } depthStencil;
} NGFX_ClearValue;

typedef struct NGFX_RenderPassBeginInfo {
    NGFX_RenderPass             renderPass;
    NGFX_Framebuffer            framebuffer;
    NGFX_Rect2D                 renderArea;
    uint32_t                    clearValueCount;
    const NGFX_ClearValue*      pClearValues;
} NGFX_RenderPassBeginInfo;

typedef struct NGFX_PresentInfo {
    uint32_t                waitSemaphoreCount;
    const NGFX_Semaphore*   pWaitSemaphores;
    uint32_t                swapchainCount;
    const NGFX_Swapchain*   pSwapchains;
    const uint32_t*         pImageIndices;
    NGFX_Result*            pResults;
} NGFX_PresentInfo;

//=============================================================================
// Platform‑specific surface creation (Win32 example)
//=============================================================================
#ifdef _WIN32
typedef struct NGFX_Win32SurfaceCreateInfo {
    void*                       hinstance;
    void*                       hwnd;
} NGFX_Win32SurfaceCreateInfo;
#endif

//=============================================================================
// Function Declarations
//=============================================================================

// Instance
NGFX_API NGFX_Result ngfxCreateInstance(const NGFX_InstanceCreateInfo* pCreateInfo,
                                        NGFX_Instance* pInstance);
NGFX_API void ngfxDestroyInstance(NGFX_Instance instance);

// Physical device
NGFX_API NGFX_Result ngfxEnumeratePhysicalDevices(NGFX_Instance instance,
                                                   uint32_t* pCount,
                                                   NGFX_PhysicalDevice* pDevices);
NGFX_API void ngfxGetPhysicalDeviceProperties(NGFX_PhysicalDevice physicalDevice,
                                              NGFX_PhysicalDeviceProperties* pProperties);

// Device
NGFX_API NGFX_Result ngfxCreateDevice(NGFX_PhysicalDevice physicalDevice,
                                      const NGFX_DeviceCreateInfo* pCreateInfo,
                                      NGFX_Device* pDevice);
NGFX_API void ngfxDestroyDevice(NGFX_Device device);
NGFX_API void ngfxGetDeviceQueue(NGFX_Device device,
                                 uint32_t queueFamilyIndex,
                                 uint32_t queueIndex,
                                 NGFX_Queue* pQueue);
NGFX_API NGFX_Result ngfxDeviceWaitIdle(NGFX_Device device);

// Command pools
NGFX_API NGFX_Result ngfxCreateCommandPool(NGFX_Device device,
                                           const NGFX_CommandPoolCreateInfo* pCreateInfo,
                                           NGFX_CommandPool* pPool);
NGFX_API void ngfxDestroyCommandPool(NGFX_Device device, NGFX_CommandPool pool);

// Command buffers
NGFX_API NGFX_Result ngfxAllocateCommandBuffers(NGFX_Device device,
                                                const NGFX_CommandBufferAllocateInfo* pAllocateInfo,
                                                NGFX_CommandBuffer* pCommandBuffers);
NGFX_API void ngfxFreeCommandBuffers(NGFX_Device device,
                                      NGFX_CommandPool commandPool,
                                      uint32_t commandBufferCount,
                                      const NGFX_CommandBuffer* pCommandBuffers);
NGFX_API NGFX_Result ngfxBeginCommandBuffer(NGFX_CommandBuffer commandBuffer,
                                            const NGFX_CommandBufferBeginInfo* pBeginInfo);
NGFX_API NGFX_Result ngfxEndCommandBuffer(NGFX_CommandBuffer commandBuffer);
NGFX_API NGFX_Result ngfxResetCommandBuffer(NGFX_CommandBuffer commandBuffer,
                                            NGFX_Flags flags);

// Queue
NGFX_API NGFX_Result ngfxQueueSubmit(NGFX_Queue queue,
                                     uint32_t submitCount,
                                     const NGFX_SubmitInfo* pSubmits,
                                     NGFX_Fence fence);
NGFX_API NGFX_Result ngfxQueueWaitIdle(NGFX_Queue queue);

// Synchronization
NGFX_API NGFX_Result ngfxCreateFence(NGFX_Device device,
                                     const NGFX_FenceCreateInfo* pCreateInfo,
                                     NGFX_Fence* pFence);
NGFX_API void ngfxDestroyFence(NGFX_Device device, NGFX_Fence fence);
NGFX_API NGFX_Result ngfxWaitForFences(NGFX_Device device,
                                       uint32_t fenceCount,
                                       const NGFX_Fence* pFences,
                                       NGFX_Bool waitAll,
                                       uint64_t timeout);
NGFX_API NGFX_Result ngfxResetFences(NGFX_Device device,
                                     uint32_t fenceCount,
                                     const NGFX_Fence* pFences);
NGFX_API NGFX_Result ngfxCreateSemaphore(NGFX_Device device,
                                         const NGFX_SemaphoreCreateInfo* pCreateInfo,
                                         NGFX_Semaphore* pSemaphore);
NGFX_API void ngfxDestroySemaphore(NGFX_Device device, NGFX_Semaphore semaphore);

// Render pass
NGFX_API NGFX_Result ngfxCreateRenderPass(NGFX_Device device,
                                          const NGFX_RenderPassCreateInfo* pCreateInfo,
                                          NGFX_RenderPass* pRenderPass);
NGFX_API void ngfxDestroyRenderPass(NGFX_Device device, NGFX_RenderPass renderPass);

// Framebuffer
NGFX_API NGFX_Result ngfxCreateFramebuffer(NGFX_Device device,
                                           const NGFX_FramebufferCreateInfo* pCreateInfo,
                                           NGFX_Framebuffer* pFramebuffer);
NGFX_API void ngfxDestroyFramebuffer(NGFX_Device device, NGFX_Framebuffer framebuffer);

// Shader module
NGFX_API NGFX_Result ngfxCreateShaderModule(NGFX_Device device,
                                            const NGFX_ShaderModuleCreateInfo* pCreateInfo,
                                            NGFX_ShaderModule* pShaderModule);
NGFX_API void ngfxDestroyShaderModule(NGFX_Device device, NGFX_ShaderModule shaderModule);

// Pipeline layout
NGFX_API NGFX_Result ngfxCreatePipelineLayout(NGFX_Device device,
                                              const NGFX_PipelineLayoutCreateInfo* pCreateInfo,
                                              NGFX_PipelineLayout* pLayout);
NGFX_API void ngfxDestroyPipelineLayout(NGFX_Device device, NGFX_PipelineLayout layout);

// Graphics pipeline
NGFX_API NGFX_Result ngfxCreateGraphicsPipelines(NGFX_Device device,
                                                  NGFX_PipelineCache pipelineCache,
                                                  uint32_t createInfoCount,
                                                  const NGFX_GraphicsPipelineCreateInfo* pCreateInfos,
                                                  NGFX_Pipeline* pPipelines);
NGFX_API void ngfxDestroyPipeline(NGFX_Device device, NGFX_Pipeline pipeline);

// Buffer
NGFX_API NGFX_Result ngfxCreateBuffer(NGFX_Device device,
                                      const NGFX_BufferCreateInfo* pCreateInfo,
                                      NGFX_Buffer* pBuffer);
NGFX_API void ngfxDestroyBuffer(NGFX_Device device, NGFX_Buffer buffer);

// Image
NGFX_API NGFX_Result ngfxCreateImage(NGFX_Device device,
                                     const NGFX_ImageCreateInfo* pCreateInfo,
                                     NGFX_Image* pImage);
NGFX_API void ngfxDestroyImage(NGFX_Device device, NGFX_Image image);

// Image view
NGFX_API NGFX_Result ngfxCreateImageView(NGFX_Device device,
                                         const NGFX_ImageViewCreateInfo* pCreateInfo,
                                         NGFX_ImageView* pImageView);
NGFX_API void ngfxDestroyImageView(NGFX_Device device, NGFX_ImageView imageView);

// Sampler
NGFX_API NGFX_Result ngfxCreateSampler(NGFX_Device device,
                                       const NGFX_SamplerCreateInfo* pCreateInfo,
                                       NGFX_Sampler* pSampler);
NGFX_API void ngfxDestroySampler(NGFX_Device device, NGFX_Sampler sampler);

// Commands recorded to command buffers
NGFX_API void ngfxCmdBeginRenderPass(NGFX_CommandBuffer commandBuffer,
                                      const NGFX_RenderPassBeginInfo* pRenderPassBegin,
                                      NGFX_SubpassContents contents);
NGFX_API void ngfxCmdEndRenderPass(NGFX_CommandBuffer commandBuffer);
NGFX_API void ngfxCmdBindPipeline(NGFX_CommandBuffer commandBuffer,
                                   NGFX_PipelineBindPoint pipelineBindPoint,
                                   NGFX_Pipeline pipeline);
NGFX_API void ngfxCmdBindVertexBuffers(NGFX_CommandBuffer commandBuffer,
                                        uint32_t firstBinding,
                                        uint32_t bindingCount,
                                        const NGFX_Buffer* pBuffers,
                                        const NGFX_DeviceSize* pOffsets);
NGFX_API void ngfxCmdBindIndexBuffer(NGFX_CommandBuffer commandBuffer,
                                      NGFX_Buffer buffer,
                                      NGFX_DeviceSize offset,
                                      NGFX_IndexType indexType);
NGFX_API void ngfxCmdDraw(NGFX_CommandBuffer commandBuffer,
                          uint32_t vertexCount,
                          uint32_t instanceCount,
                          uint32_t firstVertex,
                          uint32_t firstInstance);
NGFX_API void ngfxCmdDrawIndexed(NGFX_CommandBuffer commandBuffer,
                                 uint32_t indexCount,
                                 uint32_t instanceCount,
                                 uint32_t firstIndex,
                                 int32_t vertexOffset,
                                 uint32_t firstInstance);
NGFX_API void ngfxCmdSetViewport(NGFX_CommandBuffer commandBuffer,
                                  uint32_t firstViewport,
                                  uint32_t viewportCount,
                                  const NGFX_Viewport* pViewports);
NGFX_API void ngfxCmdSetScissor(NGFX_CommandBuffer commandBuffer,
                                 uint32_t firstScissor,
                                 uint32_t scissorCount,
                                 const NGFX_Rect2D* pScissors);

// Surface and swapchain (platform specific)
#ifdef _WIN32
NGFX_API NGFX_Result ngfxCreateWin32Surface(NGFX_Instance instance,
                                            const NGFX_Win32SurfaceCreateInfo* pCreateInfo,
                                            NGFX_Surface* pSurface);
#endif

NGFX_API void ngfxDestroySurface(NGFX_Instance instance, NGFX_Surface surface);
NGFX_API NGFX_Result ngfxGetPhysicalDeviceSurfaceSupport(NGFX_PhysicalDevice physicalDevice,
                                                          uint32_t queueFamilyIndex,
                                                          NGFX_Surface surface,
                                                          NGFX_Bool* pSupported);

typedef struct NGFX_SwapchainCreateInfo {
    NGFX_Surface                surface;
    uint32_t                    minImageCount;
    NGFX_Format                 imageFormat;
    uint32_t                    imageColorSpace;
    uint32_t                    imageExtent_width;
    uint32_t                    imageExtent_height;
    uint32_t                    imageArrayLayers;
    uint32_t                    imageUsage;
    uint32_t                    imageSharingMode;
    uint32_t                    queueFamilyIndexCount;
    const uint32_t*             pQueueFamilyIndices;
    uint32_t                    preTransform;
    uint32_t                    compositeAlpha;
    uint32_t                    presentMode;
    NGFX_Bool                   clipped;
    NGFX_Swapchain              oldSwapchain;
} NGFX_SwapchainCreateInfo;

NGFX_API NGFX_Result ngfxCreateSwapchain(NGFX_Device device,
                                         const NGFX_SwapchainCreateInfo* pCreateInfo,
                                         NGFX_Swapchain* pSwapchain);
NGFX_API void ngfxDestroySwapchain(NGFX_Device device, NGFX_Swapchain swapchain);
NGFX_API NGFX_Result ngfxGetSwapchainImages(NGFX_Device device,
                                             NGFX_Swapchain swapchain,
                                             uint32_t* pCount,
                                             NGFX_Image* pImages);
NGFX_API NGFX_Result ngfxAcquireNextImage(NGFX_Device device,
                                           NGFX_Swapchain swapchain,
                                           uint64_t timeout,
                                           NGFX_Semaphore semaphore,
                                           NGFX_Fence fence,
                                           uint32_t* pImageIndex);
NGFX_API NGFX_Result ngfxQueuePresent(NGFX_Queue queue,
                                       const NGFX_PresentInfo* pPresentInfo);

// Utility
NGFX_API const char* ngfxResultString(NGFX_Result result);

#ifdef __cplusplus
}
#endif

#endif // NGRAPHICS_H
