
// ngfx_pipeline.c – pipeline, shader module, pipeline layout functions

#include "ngraphics.h"
#include "ngfx_dispatch.h"

// Shader module
NGFX_API NGFX_Result ngfxCreateShaderModule(NGFX_Device device,
                                            const NGFX_ShaderModuleCreateInfo* pCreateInfo,
                                            NGFX_ShaderModule* pShaderModule) {
    if (!device || !pCreateInfo || !pShaderModule)
        return NGFX_ERROR_INITIALIZATION_FAILED;
    if (!g_dispatch.CreateShaderModule)
        return NGFX_ERROR_INITIALIZATION_FAILED;
    return g_dispatch.CreateShaderModule(device, pCreateInfo, pShaderModule);
}

NGFX_API void ngfxDestroyShaderModule(NGFX_Device device, NGFX_ShaderModule shaderModule) {
    if (device && shaderModule && g_dispatch.DestroyShaderModule)
        g_dispatch.DestroyShaderModule(device, shaderModule);
}

// Pipeline layout
NGFX_API NGFX_Result ngfxCreatePipelineLayout(NGFX_Device device,
                                              const NGFX_PipelineLayoutCreateInfo* pCreateInfo,
                                              NGFX_PipelineLayout* pLayout) {
    if (!device || !pCreateInfo || !pLayout)
        return NGFX_ERROR_INITIALIZATION_FAILED;
    if (!g_dispatch.CreatePipelineLayout)
        return NGFX_ERROR_INITIALIZATION_FAILED;
    return g_dispatch.CreatePipelineLayout(device, pCreateInfo, pLayout);
}

NGFX_API void ngfxDestroyPipelineLayout(NGFX_Device device, NGFX_PipelineLayout layout) {
    if (device && layout && g_dispatch.DestroyPipelineLayout)
        g_dispatch.DestroyPipelineLayout(device, layout);
}

// Graphics pipeline
NGFX_API NGFX_Result ngfxCreateGraphicsPipelines(NGFX_Device device,
                                                  NGFX_PipelineCache pipelineCache,
                                                  uint32_t createInfoCount,
                                                  const NGFX_GraphicsPipelineCreateInfo* pCreateInfos,
                                                  NGFX_Pipeline* pPipelines) {
    if (!device || createInfoCount == 0 || !pCreateInfos || !pPipelines)
        return NGFX_ERROR_INITIALIZATION_FAILED;
    if (!g_dispatch.CreateGraphicsPipelines)
        return NGFX_ERROR_INITIALIZATION_FAILED;
    return g_dispatch.CreateGraphicsPipelines(device, pipelineCache, createInfoCount, pCreateInfos, pPipelines);
}

NGFX_API void ngfxDestroyPipeline(NGFX_Device device, NGFX_Pipeline pipeline) {
    if (device && pipeline && g_dispatch.DestroyPipeline)
        g_dispatch.DestroyPipeline(device, pipeline);
}