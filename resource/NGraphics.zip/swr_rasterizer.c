
// swr_rasterizer.c – software rasterizer (command execution and triangle drawing)

#include "ngraphics.h"
#include "ngfx_dispatch.h"
#include "swr_common.h"
#include <stdlib.h>
#include <string.h>
#include <math.h>

#ifndef max
#define max(a,b) (((a) > (b)) ? (a) : (b))
#endif
#ifndef min
#define min(a,b) (((a) < (b)) ? (a) : (b))
#endif

static float edge_function(const SwrVertex* a, const SwrVertex* b, const SwrVertex* c) {
    return (b->x - a->x) * (c->y - a->y) - (b->y - a->y) * (c->x - a->x);
}

static void swr_draw_triangle(SwrVertex v0, SwrVertex v1, SwrVertex v2,
                               const SwrPipeline* pipeline,
                               uint32_t* framebuffer, float* depthBuffer,
                               int fbWidth, int fbHeight,
                               const NGFX_Viewport* viewport,
                               const NGFX_Rect2D* scissor) {
    (void)viewport;
    int minX = (int)fminf(v0.x, fminf(v1.x, v2.x));
    int minY = (int)fminf(v0.y, fminf(v1.y, v2.y));
    int maxX = (int)fmaxf(v0.x, fmaxf(v1.x, v2.x));
    int maxY = (int)fmaxf(v0.y, fmaxf(v1.y, v2.y));

    int scX = scissor ? scissor->x : 0;
    int scY = scissor ? scissor->y : 0;
    int scW = scissor ? scissor->width : fbWidth;
    int scH = scissor ? scissor->height : fbHeight;

    minX = max(minX, scX);
    minY = max(minY, scY);
    maxX = min(maxX, scX + scW - 1);
    maxY = min(maxY, scY + scH - 1);

    if (minX > maxX || minY > maxY) return;

    float area = edge_function(&v0, &v1, &v2);
    if (area == 0.0f) return;

    if (pipeline && (pipeline->rasterizationState.cullMode != NGFX_CULL_MODE_NONE)) {
        NGFX_Bool frontFaceIsCCW = (pipeline->rasterizationState.frontFace == NGFX_FRONT_FACE_COUNTER_CLOCKWISE);
        NGFX_Bool triangleIsCCW = (area > 0);
        NGFX_Bool frontFace = (frontFaceIsCCW == triangleIsCCW);
        if ((pipeline->rasterizationState.cullMode == NGFX_CULL_MODE_FRONT_BIT && frontFace) ||
            (pipeline->rasterizationState.cullMode == NGFX_CULL_MODE_BACK_BIT && !frontFace)) {
            return;
        }
    }

    for (int y = minY; y <= maxY; ++y) {
        for (int x = minX; x <= maxX; ++x) {
            SwrVertex p;
            p.x = (float)x + 0.5f;
            p.y = (float)y + 0.5f;

            float w0 = edge_function(&v1, &v2, &p);
            float w1 = edge_function(&v2, &v0, &p);
            float w2 = edge_function(&v0, &v1, &p);

            if ((area > 0 && (w0 >= 0 && w1 >= 0 && w2 >= 0)) ||
                (area < 0 && (w0 <= 0 && w1 <= 0 && w2 <= 0))) {
                w0 /= area;
                w1 /= area;
                w2 /= area;

                float z = v0.z * w0 + v1.z * w1 + v2.z * w2;
                int pixelIndex = y * fbWidth + x;

                if (depthBuffer && pipeline && pipeline->depthStencilState.depthTestEnable) {
                    float currentZ = depthBuffer[pixelIndex];
                    NGFX_Bool depthPass = NGFX_FALSE;
                    switch (pipeline->depthStencilState.depthCompareOp) {
                        case NGFX_COMPARE_OP_NEVER: depthPass = NGFX_FALSE; break;
                        case NGFX_COMPARE_OP_LESS: depthPass = (z < currentZ) ? NGFX_TRUE : NGFX_FALSE; break;
                        case NGFX_COMPARE_OP_EQUAL: depthPass = (z == currentZ) ? NGFX_TRUE : NGFX_FALSE; break;
                        case NGFX_COMPARE_OP_LESS_OR_EQUAL: depthPass = (z <= currentZ) ? NGFX_TRUE : NGFX_FALSE; break;
                        case NGFX_COMPARE_OP_GREATER: depthPass = (z > currentZ) ? NGFX_TRUE : NGFX_FALSE; break;
                        case NGFX_COMPARE_OP_NOT_EQUAL: depthPass = (z != currentZ) ? NGFX_TRUE : NGFX_FALSE; break;
                        case NGFX_COMPARE_OP_GREATER_OR_EQUAL: depthPass = (z >= currentZ) ? NGFX_TRUE : NGFX_FALSE; break;
                        case NGFX_COMPARE_OP_ALWAYS: depthPass = NGFX_TRUE; break;
                        default: depthPass = NGFX_FALSE;
                    }
                    if (!depthPass) continue;
                    if (pipeline->depthStencilState.depthWriteEnable) {
                        depthBuffer[pixelIndex] = z;
                    }
                }

                float r = v0.r * w0 + v1.r * w1 + v2.r * w2;
                float g = v0.g * w0 + v1.g * w1 + v2.g * w2;
                float b = v0.b * w0 + v1.b * w1 + v2.b * w2;
                float a = v0.a * w0 + v1.a * w1 + v2.a * w2;

                r = fminf(1.0f, fmaxf(0.0f, r));
                g = fminf(1.0f, fmaxf(0.0f, g));
                b = fminf(1.0f, fmaxf(0.0f, b));
                a = fminf(1.0f, fmaxf(0.0f, a));

                uint32_t color = ((uint32_t)(a * 255) << 24) |
                                 ((uint32_t)(r * 255) << 16) |
                                 ((uint32_t)(g * 255) << 8) |
                                 ((uint32_t)(b * 255));
                framebuffer[pixelIndex] = color;
            }
        }
    }
}

void swr_execute_command_buffer(NGFX_CommandBuffer cmdBuffer) {
    if (!cmdBuffer) return;
    SwrCommandBuffer* swrCmdBuf = (SwrCommandBuffer*)cmdBuffer;

    SwrPipeline* currentPipeline = NULL;
    NGFX_Viewport viewport = {0,0,0,0,0,1};
    NGFX_Rect2D scissor = {0,0,0,0};
    uint32_t* framebuffer = NULL;
    float* depthBuffer = NULL;
    int fbWidth = 0, fbHeight = 0;

    for (uint32_t i = 0; i < swrCmdBuf->count; ++i) {
        SwrCommand* cmd = &swrCmdBuf->commands[i];
        switch (cmd->type) {
            case SWR_CMD_BIND_PIPELINE:
                currentPipeline = (SwrPipeline*)cmd->data.bindPipeline.pipeline;
                break;
            case SWR_CMD_SET_VIEWPORT:
                if (cmd->data.setViewport.viewportCount > 0)
                    viewport = cmd->data.setViewport.viewports[0];
                break;
            case SWR_CMD_SET_SCISSOR:
                if (cmd->data.setScissor.scissorCount > 0)
                    scissor = cmd->data.setScissor.scissors[0];
                break;
            case SWR_CMD_BEGIN_RENDERPASS: {
                fbWidth = 640; fbHeight = 480;
                framebuffer = (uint32_t*)malloc(fbWidth * fbHeight * 4);
                depthBuffer = (float*)malloc(fbWidth * fbHeight * sizeof(float));
                break;
            }
            case SWR_CMD_END_RENDERPASS:
                free(framebuffer); free(depthBuffer);
                framebuffer = NULL; depthBuffer = NULL;
                break;
            case SWR_CMD_DRAW:
                if (currentPipeline && framebuffer && depthBuffer) {
                    SwrVertex v0 = {100,100,0.5f, 1,0,0,1};
                    SwrVertex v1 = {200,100,0.5f, 0,1,0,1};
                    SwrVertex v2 = {150,200,0.5f, 0,0,1,1};
                    swr_draw_triangle(v0, v1, v2, currentPipeline,
                                      framebuffer, depthBuffer,
                                      fbWidth, fbHeight,
                                      &viewport, &scissor);
                }
                break;
            default:
                break;
        }
    }
}