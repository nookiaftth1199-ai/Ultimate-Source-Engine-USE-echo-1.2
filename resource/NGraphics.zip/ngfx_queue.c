
// ngfx_queue.c – queue functions

#include "ngraphics.h"
#include "ngfx_dispatch.h"

NGFX_API NGFX_Result ngfxQueueSubmit(NGFX_Queue queue,
                                     uint32_t submitCount,
                                     const NGFX_SubmitInfo* pSubmits,
                                     NGFX_Fence fence) {
    if (!queue || submitCount == 0 || !pSubmits)
        return NGFX_ERROR_INITIALIZATION_FAILED;
    if (!g_dispatch.QueueSubmit)
        return NGFX_ERROR_INITIALIZATION_FAILED;
    return g_dispatch.QueueSubmit(queue, submitCount, pSubmits, fence);
}

NGFX_API NGFX_Result ngfxQueueWaitIdle(NGFX_Queue queue) {
    if (!queue)
        return NGFX_ERROR_INITIALIZATION_FAILED;
    if (!g_dispatch.QueueWaitIdle)
        return NGFX_ERROR_INITIALIZATION_FAILED;
    return g_dispatch.QueueWaitIdle(queue);
}

NGFX_API NGFX_Result ngfxQueuePresent(NGFX_Queue queue,
                                       const NGFX_PresentInfo* pPresentInfo) {
    if (!queue || !pPresentInfo)
        return NGFX_ERROR_INITIALIZATION_FAILED;
    if (!g_dispatch.QueuePresent)
        return NGFX_ERROR_INITIALIZATION_FAILED;
    return g_dispatch.QueuePresent(queue, (const void*)pPresentInfo);
}