
// ngfx_renderpass.c – render pass functions only

#include "ngraphics.h"
#include "ngfx_dispatch.h"

NGFX_API NGFX_Result ngfxCreateRenderPass(NGFX_Device device,
                                          const NGFX_RenderPassCreateInfo* pCreateInfo,
                                          NGFX_RenderPass* pRenderPass) {
    if (!device || !pCreateInfo || !pRenderPass)
        return NGFX_ERROR_INITIALIZATION_FAILED;
    if (!g_dispatch.CreateRenderPass)
        return NGFX_ERROR_INITIALIZATION_FAILED;
    return g_dispatch.CreateRenderPass(device, pCreateInfo, pRenderPass);
}

NGFX_API void ngfxDestroyRenderPass(NGFX_Device device, NGFX_RenderPass renderPass) {
    if (device && renderPass && g_dispatch.DestroyRenderPass)
        g_dispatch.DestroyRenderPass(device, renderPass);
}