﻿
#include "ngraphics.h"
#include <stdio.h>

int main() {
    NGFX_Instance instance;
    NGFX_InstanceCreateInfo instInfo = {0};
    instInfo.pApplicationInfo = &(NGFX_ApplicationInfo){
        .pApplicationName = "Minimal Test",
        .applicationVersion = 1,
        .apiVersion = NGFX_API_VERSION
    };

    NGFX_Result res = ngfxCreateInstance(&instInfo, &instance);
    if (res != NGFX_SUCCESS) {
        printf("Failed to create instance: %s\n", ngfxResultString(res));
        return 1;
    }
    printf("Instance created successfully!\n");

    uint32_t count = 0;
    ngfxEnumeratePhysicalDevices(instance, &count, NULL);
    printf("Physical devices available: %u\n", count);

    ngfxDestroyInstance(instance);
    return 0;
