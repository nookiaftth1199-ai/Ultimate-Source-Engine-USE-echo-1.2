
// ngfx_dispatch.c – global dispatch table and backend loader

#include "ngfx_dispatch.h"
#include <string.h>

NGFX_DispatchTable g_dispatch;

extern void ngfx_swr_load_dispatch(NGFX_DispatchTable* dispatch);

NGFX_Result ngfxLoadBackend(NGFX_BackendType type) {
    memset(&g_dispatch, 0, sizeof(g_dispatch));

    switch (type) {
        case NGFX_BACKEND_SOFTWARE:
            ngfx_swr_load_dispatch(&g_dispatch);
            return NGFX_SUCCESS;
        case NGFX_BACKEND_VULKAN:
            return NGFX_ERROR_INITIALIZATION_FAILED;
        default:
            return NGFX_ERROR_INITIALIZATION_FAILED;
    }
}