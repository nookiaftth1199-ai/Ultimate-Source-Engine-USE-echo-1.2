
// swr_pipeline.c – software backend pipeline functions

#include "ngraphics.h"
#include "ngfx_dispatch.h"
#include "swr_common.h"
#include <stdlib.h>
#include <string.h>

static NGFX_Result swrCreateShaderModule(NGFX_Device device,
                                          const NGFX_ShaderModuleCreateInfo* pCreateInfo,
                                          NGFX_ShaderModule* pShaderModule) {
    (void)device;
    if (!pCreateInfo || !pShaderModule) return NGFX_ERROR_INITIALIZATION_FAILED;
    SwrShaderModule* module = (SwrShaderModule*)malloc(sizeof(SwrShaderModule));
    if (!module) return NGFX_ERROR_OUT_OF_HOST_MEMORY;
    module->codeSize = pCreateInfo->codeSize;
    module->pCode = (uint32_t*)malloc(pCreateInfo->codeSize);
    if (!module->pCode) { free(module); return NGFX_ERROR_OUT_OF_HOST_MEMORY; }
    memcpy(module->pCode, pCreateInfo->pCode, pCreateInfo->codeSize);
    *pShaderModule = (NGFX_ShaderModule)module;
    return NGFX_SUCCESS;
}

static void swrDestroyShaderModule(NGFX_Device device, NGFX_ShaderModule shaderModule) {
    (void)device;
    if (!shaderModule) return;
    SwrShaderModule* module = (SwrShaderModule*)shaderModule;
    if (module->pCode) free(module->pCode);
    free(module);
}

static NGFX_Result swrCreatePipelineLayout(NGFX_Device device,
                                            const NGFX_PipelineLayoutCreateInfo* pCreateInfo,
                                            NGFX_PipelineLayout* pLayout) {
    (void)device;
    if (!pCreateInfo || !pLayout) return NGFX_ERROR_INITIALIZATION_FAILED;
    SwrPipelineLayout* layout = (SwrPipelineLayout*)malloc(sizeof(SwrPipelineLayout));
    if (!layout) return NGFX_ERROR_OUT_OF_HOST_MEMORY;
    layout->dummy = 0;
    *pLayout = (NGFX_PipelineLayout)layout;
    return NGFX_SUCCESS;
}

static void swrDestroyPipelineLayout(NGFX_Device device, NGFX_PipelineLayout layout) {
    (void)device;
    if (layout) free(layout);
}

static NGFX_Result swrCreateGraphicsPipelines(NGFX_Device device,
                                                NGFX_PipelineCache pipelineCache,
                                                uint32_t createInfoCount,
                                                const NGFX_GraphicsPipelineCreateInfo* pCreateInfos,
                                                NGFX_Pipeline* pPipelines) {
    (void)device; (void)pipelineCache;
    if (createInfoCount == 0 || !pCreateInfos || !pPipelines)
        return NGFX_ERROR_INITIALIZATION_FAILED;
    for (uint32_t i = 0; i < createInfoCount; ++i) {
        const NGFX_GraphicsPipelineCreateInfo* info = &pCreateInfos[i];
        SwrPipeline* pipeline = (SwrPipeline*)calloc(1, sizeof(SwrPipeline));
        if (!pipeline) return NGFX_ERROR_OUT_OF_HOST_MEMORY;
        // Copy relevant state – simplified
        if (info->pVertexInputState)
            pipeline->vertexInputState = *info->pVertexInputState;
        if (info->pInputAssemblyState)
            pipeline->inputAssemblyState = *info->pInputAssemblyState;
        if (info->pViewportState)
            pipeline->viewportState = *info->pViewportState;
        if (info->pRasterizationState)
            pipeline->rasterizationState = *info->pRasterizationState;
        if (info->pMultisampleState)
            pipeline->multisampleState = *info->pMultisampleState;
        if (info->pDepthStencilState)
            pipeline->depthStencilState = *info->pDepthStencilState;
        if (info->pColorBlendState) {
            pipeline->colorBlendState = *info->pColorBlendState;
            if (info->pColorBlendState->attachmentCount > 0 && info->pColorBlendState->pAttachments) {
                pipeline->pAttachments = (NGFX_PipelineColorBlendAttachmentState*)malloc(
                    info->pColorBlendState->attachmentCount * sizeof(NGFX_PipelineColorBlendAttachmentState));
                if (pipeline->pAttachments) {
                    memcpy(pipeline->pAttachments, info->pColorBlendState->pAttachments,
                           info->pColorBlendState->attachmentCount * sizeof(NGFX_PipelineColorBlendAttachmentState));
                    pipeline->colorBlendState.pAttachments = pipeline->pAttachments;
                }
            }
        }
        pipeline->layout = info->layout;
        pipeline->renderPass = info->renderPass;
        pipeline->subpass = info->subpass;
        pPipelines[i] = (NGFX_Pipeline)pipeline;
    }
    return NGFX_SUCCESS;
}

static void swrDestroyPipeline(NGFX_Device device, NGFX_Pipeline pipeline) {
    (void)device;
    if (!pipeline) return;
    SwrPipeline* pipe = (SwrPipeline*)pipeline;
    if (pipe->pAttachments) free(pipe->pAttachments);
    free(pipe);
}

void swr_load_pipeline_dispatch(NGFX_DispatchTable* dispatch) {
    if (!dispatch) return;
    dispatch->CreateShaderModule = swrCreateShaderModule;
    dispatch->DestroyShaderModule = swrDestroyShaderModule;
    dispatch->CreatePipelineLayout = swrCreatePipelineLayout;
    dispatch->DestroyPipelineLayout = swrDestroyPipelineLayout;
    dispatch->CreateGraphicsPipelines = swrCreateGraphicsPipelines;
    dispatch->DestroyPipeline = swrDestroyPipeline;
}