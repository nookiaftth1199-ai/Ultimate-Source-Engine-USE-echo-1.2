# NGraphics

A cross‑platform 2D/3D graphics library with a Vulkan‑style explicit API. Written in C99 (compatible with C++98) and designed to run on any platform and architecture via a software renderer backend.

## Features

- **Explicit, low‑overhead API** modeled after Vulkan.
- **Software backend** – runs on any CPU without GPU support.
- **Modular design** – easy to add new backends (Vulkan, Direct3D, etc.).
- **Cross‑platform** – Windows, Linux, Android, macOS, iOS.
- **No external dependencies** for the core software renderer.

## Building

The project uses CMake. Example build for Android (Termux):

```bash
mkdir build && cd build
cmake ..
make