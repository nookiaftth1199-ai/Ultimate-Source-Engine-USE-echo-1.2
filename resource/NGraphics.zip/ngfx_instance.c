
// ngfx_instance.c – instance, physical device, surface, swapchain functions

#include "ngraphics.h"
#include "ngraphics_platform.h"
#include "ngfx_dispatch.h"

#include <stdlib.h>
#include <string.h>
#include <stdio.h>

struct NGFX_Instance_T {
    int dummy;
};

//---------------------------------------------------------------------------
// Instance
//---------------------------------------------------------------------------
NGFX_API NGFX_Result ngfxCreateInstance(const NGFX_InstanceCreateInfo* pCreateInfo,
                                        NGFX_Instance* pInstance) {
    if (!pCreateInfo || !pInstance) return NGFX_ERROR_INITIALIZATION_FAILED;
    NGFX_Result res = ngfxLoadBackend(NGFX_BACKEND_SOFTWARE);
    if (res != NGFX_SUCCESS) return res;
    if (!g_dispatch.CreateInstance) return NGFX_ERROR_INITIALIZATION_FAILED;
    return g_dispatch.CreateInstance(pCreateInfo, pInstance);
}

NGFX_API void ngfxDestroyInstance(NGFX_Instance instance) {
    if (instance && g_dispatch.DestroyInstance)
        g_dispatch.DestroyInstance(instance);
}

//---------------------------------------------------------------------------
// Physical device
//---------------------------------------------------------------------------
NGFX_API NGFX_Result ngfxEnumeratePhysicalDevices(NGFX_Instance instance,
                                                   uint32_t* pCount,
                                                   NGFX_PhysicalDevice* pDevices) {
    if (!instance || !pCount) return NGFX_ERROR_INITIALIZATION_FAILED;
    if (!g_dispatch.EnumeratePhysicalDevices) return NGFX_ERROR_INITIALIZATION_FAILED;
    return g_dispatch.EnumeratePhysicalDevices(instance, pCount, pDevices);
}

NGFX_API void ngfxGetPhysicalDeviceProperties(NGFX_PhysicalDevice physicalDevice,
                                              NGFX_PhysicalDeviceProperties* pProperties) {
    if (physicalDevice && pProperties && g_dispatch.GetPhysicalDeviceProperties)
        g_dispatch.GetPhysicalDeviceProperties(physicalDevice, pProperties);
}

//---------------------------------------------------------------------------
// Surface and swapchain (platform‑specific stubs)
//---------------------------------------------------------------------------
#ifdef NGFX_PLATFORM_WINDOWS
NGFX_API NGFX_Result ngfxCreateWin32Surface(NGFX_Instance instance,
                                            const NGFX_Win32SurfaceCreateInfo* pCreateInfo,
                                            NGFX_Surface* pSurface) {
    if (!instance || !pCreateInfo || !pSurface) return NGFX_ERROR_INITIALIZATION_FAILED;
    if (!g_dispatch.CreateSurface) return NGFX_ERROR_INITIALIZATION_FAILED;
    return g_dispatch.CreateSurface(instance, (const void*)pCreateInfo, pSurface);
}
#endif

NGFX_API void ngfxDestroySurface(NGFX_Instance instance, NGFX_Surface surface) {
    if (instance && surface && g_dispatch.DestroySurface)
        g_dispatch.DestroySurface(instance, surface);
}

NGFX_API NGFX_Result ngfxGetPhysicalDeviceSurfaceSupport(NGFX_PhysicalDevice physicalDevice,
                                                          uint32_t queueFamilyIndex,
                                                          NGFX_Surface surface,
                                                          NGFX_Bool* pSupported) {
    if (!physicalDevice || !surface || !pSupported) return NGFX_ERROR_INITIALIZATION_FAILED;
    if (!g_dispatch.GetPhysicalDeviceSurfaceSupport) return NGFX_ERROR_INITIALIZATION_FAILED;
    return g_dispatch.GetPhysicalDeviceSurfaceSupport(physicalDevice, queueFamilyIndex, surface, pSupported);
}

NGFX_API NGFX_Result ngfxCreateSwapchain(NGFX_Device device,
                                         const NGFX_SwapchainCreateInfo* pCreateInfo,
                                         NGFX_Swapchain* pSwapchain) {
    if (!device || !pCreateInfo || !pSwapchain) return NGFX_ERROR_INITIALIZATION_FAILED;
    if (!g_dispatch.CreateSwapchain) return NGFX_ERROR_INITIALIZATION_FAILED;
    return g_dispatch.CreateSwapchain(device, pCreateInfo, pSwapchain);
}

NGFX_API void ngfxDestroySwapchain(NGFX_Device device, NGFX_Swapchain swapchain) {
    if (device && swapchain && g_dispatch.DestroySwapchain)
        g_dispatch.DestroySwapchain(device, swapchain);
}

NGFX_API NGFX_Result ngfxGetSwapchainImages(NGFX_Device device,
                                             NGFX_Swapchain swapchain,
                                             uint32_t* pCount,
                                             NGFX_Image* pImages) {
    if (!device || !swapchain || !pCount) return NGFX_ERROR_INITIALIZATION_FAILED;
    if (!g_dispatch.GetSwapchainImages) return NGFX_ERROR_INITIALIZATION_FAILED;
    return g_dispatch.GetSwapchainImages(device, swapchain, pCount, pImages);
}

NGFX_API NGFX_Result ngfxAcquireNextImage(NGFX_Device device,
                                           NGFX_Swapchain swapchain,
                                           uint64_t timeout,
                                           NGFX_Semaphore semaphore,
                                           NGFX_Fence fence,
                                           uint32_t* pImageIndex) {
    if (!device || !swapchain || !pImageIndex) return NGFX_ERROR_INITIALIZATION_FAILED;
    if (!g_dispatch.AcquireNextImage) return NGFX_ERROR_INITIALIZATION_FAILED;
    return g_dispatch.AcquireNextImage(device, swapchain, timeout, semaphore, fence, pImageIndex);
}

//---------------------------------------------------------------------------
// Utility
//---------------------------------------------------------------------------
NGFX_API const char* ngfxResultString(NGFX_Result result) {
    switch (result) {
        case NGFX_SUCCESS: return "Success";
        case NGFX_ERROR_OUT_OF_HOST_MEMORY: return "Out of host memory";
        case NGFX_ERROR_OUT_OF_DEVICE_MEMORY: return "Out of device memory";
        case NGFX_ERROR_INITIALIZATION_FAILED: return "Initialization failed";
        case NGFX_ERROR_DEVICE_LOST: return "Device lost";
        case NGFX_ERROR_MEMORY_MAP_FAILED: return "Memory map failed";
        case NGFX_ERROR_LAYER_NOT_PRESENT: return "Layer not present";
        case NGFX_ERROR_EXTENSION_NOT_PRESENT: return "Extension not present";
        case NGFX_ERROR_FEATURE_NOT_PRESENT: return "Feature not present";
        case NGFX_ERROR_INCOMPATIBLE_DRIVER: return "Incompatible driver";
        case NGFX_ERROR_TOO_MANY_OBJECTS: return "Too many objects";
        case NGFX_ERROR_FORMAT_NOT_SUPPORTED: return "Format not supported";
        case NGFX_ERROR_FRAGMENTED_POOL: return "Fragmented pool";
        case NGFX_ERROR_SURFACE_LOST: return "Surface lost";
        case NGFX_ERROR_NATIVE_WINDOW_IN_USE: return "Native window in use";
        case NGFX_ERROR_OUT_OF_DATE: return "Out of date";
        case NGFX_ERROR_INCOMPATIBLE_DISPLAY: return "Incompatible display";
        case NGFX_ERROR_VALIDATION_FAILED: return "Validation failed";
        case NGFX_ERROR_INVALID_SHADER: return "Invalid shader";
        case NGFX_ERROR_INCOMPATIBLE_SHADER: return "Incompatible shader";
        default: return "Unknown error";
    }
}