
// swr_queue.c – software backend queue functions

#include "ngraphics.h"
#include "ngfx_dispatch.h"
#include "swr_common.h"
#include <stdlib.h>

extern void swr_execute_command_buffer(NGFX_CommandBuffer commandBuffer);

static NGFX_Result swrQueueSubmit(NGFX_Queue queue,
                                   uint32_t submitCount,
                                   const NGFX_SubmitInfo* pSubmits,
                                   NGFX_Fence fence) {
    (void)fence;
    if (!queue || submitCount == 0 || !pSubmits)
        return NGFX_ERROR_INITIALIZATION_FAILED;
    for (uint32_t s = 0; s < submitCount; ++s) {
        const NGFX_SubmitInfo* submit = &pSubmits[s];
        for (uint32_t cb = 0; cb < submit->commandBufferCount; ++cb) {
            if (submit->pCommandBuffers[cb])
                swr_execute_command_buffer(submit->pCommandBuffers[cb]);
        }
    }
    return NGFX_SUCCESS;
}

static NGFX_Result swrQueueWaitIdle(NGFX_Queue queue) {
    (void)queue;
    return NGFX_SUCCESS;
}

static NGFX_Result swrQueuePresent(NGFX_Queue queue, const void* pPresentInfo) {
    (void)queue; (void)pPresentInfo;
    return NGFX_SUCCESS;
}

void swr_load_queue_dispatch(NGFX_DispatchTable* dispatch) {
    if (!dispatch) return;
    dispatch->QueueSubmit = swrQueueSubmit;
    dispatch->QueueWaitIdle = swrQueueWaitIdle;
    dispatch->QueuePresent = swrQueuePresent;
}